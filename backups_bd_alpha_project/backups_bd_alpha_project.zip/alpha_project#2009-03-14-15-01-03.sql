-- MySQL dump 10.11
--
-- Host: localhost    Database: alpha_project
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (71,'3443534543','Dr.Dre feat. Snoop Dogg-Still D.R.E. The Cronic 2001 uncesor','<object data=\"http://www.youtube.com/v/ykP-ti8RzYA&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/ykP-ti8RzYA&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]ykP-ti8RzYA[/youtubecopy]-->',2008,1,4,1),(53,'2345234324','MCR','<object data=\"http://www.youtube.com/v/QGqAs_fOnSg&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/QGqAs_fOnSg&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]QGqAs_fOnSg[/youtubecopy]-->',2008,1,7,2),(77,'2334234545','Hot Chocolate','A sua sinópse aqui...',2000,1,3,1),(51,'2345535676','MCR','A sua sinópse aqui...',2008,1,0,0),(52,'2345534564','MCR','A sua sinópse aqui...',2008,1,0,0),(48,'2345464564','MCR','A sua sinópse aqui...',2008,1,0,0),(75,'2332223232','Chopin','',2005,1,0,0),(76,'2334234324','Hot Chocolate','A sua sinópse aqui...',2000,1,0,0),(47,'2342345645','MCR','A sua sinópse aqui...',2008,1,0,0),(74,'3343534354','Family Guy - Bullfrog','<object data=\"http://www.youtube.com/v/DXHaCEhOiWU&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/DXHaCEhOiWU&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object>\r\n<!--URL do filme: http://www.youtube.com/watch?v=DXHaCEhOiWU-->',2000,1,5,2);
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (1,'Música','Área dedicada à música!'),(2,'Filmes','<p></p>');
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `controlo_votacao`
--

LOCK TABLES `controlo_votacao` WRITE;
/*!40000 ALTER TABLE `controlo_votacao` DISABLE KEYS */;
INSERT INTO `controlo_votacao` VALUES (1,1,12),(1,1,53),(1,1,55),(1,1,62),(1,1,71),(1,1,74),(1,1,77),(1,1,79),(1,1,80),(1,1,81),(2,9,74);
/*!40000 ALTER TABLE `controlo_votacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_album`
--

LOCK TABLES `copi_album` WRITE;
/*!40000 ALTER TABLE `copi_album` DISABLE KEYS */;
INSERT INTO `copi_album` VALUES (53,16,3),(77,15,7),(71,16,2),(75,14,9),(75,15,3),(76,16,7),(76,15,7);
/*!40000 ALTER TABLE `copi_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_filme`
--

LOCK TABLES `copi_filme` WRITE;
/*!40000 ALTER TABLE `copi_filme` DISABLE KEYS */;
INSERT INTO `copi_filme` VALUES (0,54,3,2,9),(0,55,3,3,3),(0,56,3,2,9),(0,59,3,2,9),(0,60,3,2,9),(4,81,0,2,2),(3,12,0,3,3);
/*!40000 ALTER TABLE `copi_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_outro`
--

LOCK TABLES `copi_outro` WRITE;
/*!40000 ALTER TABLE `copi_outro` DISABLE KEYS */;
INSERT INTO `copi_outro` VALUES (79,1,1,44),(80,2,2,8);
/*!40000 ALTER TABLE `copi_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `direito_outro`
--

LOCK TABLES `direito_outro` WRITE;
/*!40000 ALTER TABLE `direito_outro` DISABLE KEYS */;
INSERT INTO `direito_outro` VALUES (1,'GNU'),(2,'Copy right');
/*!40000 ALTER TABLE `direito_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `estatuto`
--

LOCK TABLES `estatuto` WRITE;
/*!40000 ALTER TABLE `estatuto` DISABLE KEYS */;
INSERT INTO `estatuto` VALUES (1,'Admin',1,1,1,1,1,1,1,1,1,1,1,1,1),(2,'Gestor filmes',1,0,0,1,1,0,1,0,0,0,0,0,0);
/*!40000 ALTER TABLE `estatuto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `filme`
--

LOCK TABLES `filme` WRITE;
/*!40000 ALTER TABLE `filme` DISABLE KEYS */;
INSERT INTO `filme` VALUES (12,3,0,'2342342343','Matrix','','gdfgdfgdf<object data=\"http://www.youtube.com/v/QGqAs_fOnSg&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/QGqAs_fOnSg&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]http://www.youtube.com/watch?v=QGqAs_fOnSg[/youtubecopy]-->asdasdas<object data=\"http://www.youtube.com/v/V4sYKOeU7cc&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/V4sYKOeU7cc&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]http://www.youtube.com/watch?v=V4sYKOeU7cc[/youtubecopy]-->erwerwe',2000,90,0,1,15,5),(54,0,3,'3324324324','Filme1','','Ui, ui!',2008,90,9.8,1,0,0),(55,0,3,'3324324345','Filme1','','Ui, ui!',2008,90,9.8,1,4,1),(56,0,3,'3324324334','Filme1','','Ui, ui!',2008,90,9.8,1,0,0),(59,0,3,'3324334543','Filme1','','Ui, ui!',2008,90,9.8,1,0,0),(60,0,3,'3323453443','Filme1','','Ui, ui!',2008,90,9.8,1,0,0),(81,4,0,'0003273634','Matrix','','A sua sinópse aqui...',2009,90,0,1,2,1);
/*!40000 ALTER TABLE `filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `frase`
--

LOCK TABLES `frase` WRITE;
/*!40000 ALTER TABLE `frase` DISABLE KEYS */;
/*!40000 ALTER TABLE `frase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `genero_filme`
--

LOCK TABLES `genero_filme` WRITE;
/*!40000 ALTER TABLE `genero_filme` DISABLE KEYS */;
INSERT INTO `genero_filme` VALUES (4,'Sci-fi'),(3,'Comédia');
/*!40000 ALTER TABLE `genero_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `geral`
--

LOCK TABLES `geral` WRITE;
/*!40000 ALTER TABLE `geral` DISABLE KEYS */;
INSERT INTO `geral` VALUES (51,2),(77,2),(74,2),(54,1),(76,2),(80,3),(75,2),(81,1),(60,1),(12,1),(59,1),(48,2),(53,2),(52,2),(79,3),(47,2),(56,1),(55,1),(71,2);
/*!40000 ALTER TABLE `geral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `mensagem`
--

LOCK TABLES `mensagem` WRITE;
/*!40000 ALTER TABLE `mensagem` DISABLE KEYS */;
INSERT INTO `mensagem` VALUES (1,1,1,2,'2008-12-28 00:38:12','<p>Olá <b>qwewqe</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem como missão \r\n			ser o teu melhor amigo no que toca na consulta e requesição de filmes, livros, álbuns 			  ,ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na biblioteca Eça, mas 			  também para trocares impressões dentro da comunidade escolar, para isso sente-te 				    à vontade na utilização do fórum.</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(9,2,1,2,'2008-12-28 00:56:34','Encontram-se disponíveis as seguintes cópias: 7 em DVD.<p>A sua requesição foi feita em 28/12/2008.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 29-12-2008 para levantar o filme.\r\n		E aparir da data que levantar o filme tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 2.\r\n		Traga-o consigo a quando o levantamento e devolução do filme.\r\n		<a href=\"?elem=2&amp;accao=5&amp;filme=12\">\r\n		<b>Requesição do filme <u>Matrix</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Matrix</u>\"</a>\r\n		','[Filme] Matrix'),(12,1,1,3,'2008-12-29 01:02:43','<p>Olá <b>dsfds</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem como missão \r\n			ser o teu melhor amigo no que toca na consulta e requesição de filmes, álbuns, \r\n			ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na biblioteca Eça, mas 			  também para trocares impressões dentro da comunidade escolar, para isso sente-te 				    à vontade na utilização do fórum.</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(13,1,1,4,'2008-12-29 01:05:56','<p>Olá <b>dsfd</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem como missão \r\n			ser o teu melhor amigo no que toca na consulta e requesição de filmes, álbuns, \r\n			ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na biblioteca Eça, mas 			  também para trocares impressões dentro da comunidade escolar, para isso sente-te 				    à vontade na utilização do fórum.</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(14,1,1,5,'2008-12-29 01:07:16','<p>Olá <b>dsfdas</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem como missão \r\n			ser o teu melhor amigo no que toca na consulta e requesição de filmes, álbuns, \r\n			ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na biblioteca Eça, mas 			  também para trocares impressões dentro da comunidade escolar, para isso sente-te 				    à vontade na utilização do fórum.</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(15,1,1,6,'2008-12-29 01:09:10','<p>Olá <b>dsfdass</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem como missão \r\n			ser o teu melhor amigo no que toca na consulta e requesição de filmes, álbuns, \r\n			ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na biblioteca Eça, mas 			  também para trocares impressões dentro da comunidade escolar, para isso sente-te 				    à vontade na utilização do fórum.</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(16,1,1,7,'2008-12-29 01:14:07','<p>Olá <b>dsfdassdsd</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem como missão \r\n			ser o teu melhor amigo no que toca na consulta e requesição de filmes, álbuns, \r\n			ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na biblioteca Eça, mas 			  também para trocares impressões dentro da comunidade escolar, para isso sente-te 				    à vontade na utilização do fórum.</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(17,1,1,8,'2008-12-29 13:33:47','<p>Olá <b>asdas</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem como missão \r\n			ser o teu melhor amigo no que toca na consulta e requesição de filmes, álbuns, \r\n			ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na biblioteca Eça, mas 			  também para trocares impressões dentro da comunidade escolar, para isso sente-te 				    à vontade na utilização do fórum.</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(58,1,1,1,'2009-02-25 12:36:17','Encontram-se disponíveis as seguintes cópias: 1 em DVD.<p>A sua requesição foi feita em 25/02/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 02-03-2009 para levantar o filme.\r\n		E aparir da data que levantar o filme tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 26.\r\n		Traga-o consigo a quando o levantamento e devolução do filme.\r\n		<a href=\"?elem=2&amp;accao=5&amp;filme=81\">\r\n		<b>Requesição do filme <u>Matrix</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Matrix</u>\"</a>\r\n		','[Filme] Matrix');
/*!40000 ALTER TABLE `mensagem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_album`
--

LOCK TABLES `num_suport_album` WRITE;
/*!40000 ALTER TABLE `num_suport_album` DISABLE KEYS */;
INSERT INTO `num_suport_album` VALUES ('A',16,53),('A',15,77),('A',16,71),('A',14,75),('A',15,75),('A',16,76),('A',15,76);
/*!40000 ALTER TABLE `num_suport_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_filme`
--

LOCK TABLES `num_suport_filme` WRITE;
/*!40000 ALTER TABLE `num_suport_filme` DISABLE KEYS */;
INSERT INTO `num_suport_filme` VALUES ('A',54,0,3,2),('A',55,0,3,3),('A',56,0,3,2),('A',59,0,3,2),('A',60,0,3,2),('A',81,4,0,2),('A',12,3,0,3);
/*!40000 ALTER TABLE `num_suport_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_outro`
--

LOCK TABLES `num_suport_outro` WRITE;
/*!40000 ALTER TABLE `num_suport_outro` DISABLE KEYS */;
INSERT INTO `num_suport_outro` VALUES (79,'A',1,1),(80,'A',2,2);
/*!40000 ALTER TABLE `num_suport_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `outro`
--

LOCK TABLES `outro` WRITE;
/*!40000 ALTER TABLE `outro` DISABLE KEYS */;
INSERT INTO `outro` VALUES (79,1,'Olá','A sua sinópse aqui...',2000,1,0,0,'0034894877'),(80,2,'Encarta 2000','Uma enciclopédia com excelentes conteúdos.',2001,1,4,1,'0034000348');
/*!40000 ALTER TABLE `outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,1,2,1,1,'asd','2009-01-01 22:21:12',1,'\nasdsssss',1),(2,1,2,2,1,'Olá!','2009-01-17 12:34:38',1,'\nBoas',1),(5,1,2,2,1,'Olá!','2009-02-01 18:30:04',1,'\nNão',0),(4,1,2,2,1,'Olá!','2009-01-18 16:31:25',1,'\nBoas',0),(7,1,2,1,1,'Admin','2009-02-14 15:27:55',1,'\nlogin',0),(8,1,2,1,1,'Asd','2009-02-14 15:28:19',1,'\nlogn',0),(9,1,2,1,1,'Asd','2009-02-14 15:28:21',1,'\nlogn',0),(10,1,2,1,1,'dddddddddd','2009-02-14 15:28:38',1,'\nasd',0),(11,1,2,1,1,'Asd','2009-02-14 15:28:44',1,'\nasd',0),(12,1,2,1,1,'Asd','2009-02-14 15:29:00',1,'\nasdsa',0),(13,1,2,1,1,'Asd','2009-02-14 15:29:02',1,'\nasdsa',0),(14,1,2,1,1,'Asd','2009-02-14 15:29:08',1,'\njingle',0),(15,1,2,2,1,'Olá!','2009-02-18 18:15:45',1,'\noia',0),(16,1,2,2,1,'Olá!','2009-02-18 18:15:51',1,'\nboas',0),(17,1,2,2,1,'Olá!','2009-02-18 18:15:59',1,'\nboas',0),(18,1,2,2,1,'Olá!','2009-02-18 18:16:12',1,'\nKatami',0),(19,1,2,4,1,'Asdas','2009-03-06 15:47:55',1,'\nasdas',1),(20,1,2,5,1,'Dfdsf','2009-03-06 15:49:17',1,'\nsdfds',1),(21,1,2,6,1,'Dfdsf','2009-03-06 15:49:25',1,'\nsdfds',1),(22,1,2,4,1,'Asdas','2009-03-06 15:50:23',1,'\ndsfsd',0),(23,1,1,7,1,'Asdas','2009-03-06 15:51:09',1,'\nasdsa',1),(24,1,1,7,1,'Asdas','2009-03-06 15:51:14',1,'\nsadsa',0),(25,1,1,7,1,'Asdas','2009-03-06 15:53:10',1,'\nadas',0),(26,1,1,8,1,'Asdsa','2009-03-06 15:53:17',1,'\nsdfdsfsdfdsfds',1);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `realizador_filme`
--

LOCK TABLES `realizador_filme` WRITE;
/*!40000 ALTER TABLE `realizador_filme` DISABLE KEYS */;
INSERT INTO `realizador_filme` VALUES (1,0,54,3,' Campos son'),(13,0,55,3,' Campos son'),(3,0,56,3,' Campos son'),(6,0,59,3,' Campos son'),(7,0,60,3,' Campos son'),(14,4,81,0,' Rafael Campos');
/*!40000 ALTER TABLE `realizador_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `registo`
--

LOCK TABLES `registo` WRITE;
/*!40000 ALTER TABLE `registo` DISABLE KEYS */;
INSERT INTO `registo` VALUES (1,1,'Admin','login','2008-09-20','1991-09-20','imagens/avatar/1.gif','A minha assinatura','a646745','2009-03-14 01:08:33','google.com','r.rafael.campos@gmail.com',0,'Default','Default','0000-00-00',NULL),(2,1,'qwewqe','7766','2008-12-28','2000-05-26','imagens/avatar/1.gif','','asdasd12','2008-12-29 15:20:12','','',0,'sasad','asd','0000-00-00',NULL),(3,1,'Oiiiii','1234','2008-12-29','2000-11-23','imagens/avatar/1.gif','A minha assinatura','wwerwer','2008-12-29 15:07:33','','',0,'sdsa','asd','0000-00-00',NULL),(4,1,'dsfd','f639d9d910abd2c1f51425f9577f7e9193993aaa','2008-12-29','2000-11-23','','','wwerwerd','2008-12-29 00:00:00','','',1,'sdsa','asd','0000-00-00',NULL),(5,1,'dsfdas','b43774a60884ab019339c567d555e749f34f1f61','2008-12-29','2000-11-23','imagens/avatar/1.gif','','wwerwerdsa','2008-12-29 00:00:00','','',1,'sdsa','asd','0000-00-00',NULL),(6,1,'dsfdass','b43774a60884ab019339c567d555e749f34f1f61','2008-12-29','2000-11-23','','','wwerwerdsaasa','2008-12-29 00:00:00','','',1,'sdsa','asd','0000-00-00',NULL),(7,1,'dsfdassdsd','b43774a60884ab019339c567d555e749f34f1f61','2008-12-29','2000-11-23','','','wwerwerdsaasasdds','2008-12-29 00:00:00','','',1,'sdsa','asd','0000-00-00',NULL),(8,1,'asdas','1234','2008-12-29','2000-06-23','','´','´','2008-12-29 00:00:00','´','asjd@hotmail.com',0,'sdas','rtyrrt','0000-00-00',NULL),(9,2,'exemplo','1234','2008-12-29','2000-06-23','imagens/avatar/1.gif','´','sdds','2009-01-02 15:13:09','´','asjd@hotmail.com',0,'uiui','rtyrrt','0000-00-00',NULL);
/*!40000 ALTER TABLE `registo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `requesicao`
--

LOCK TABLES `requesicao` WRITE;
/*!40000 ALTER TABLE `requesicao` DISABLE KEYS */;
INSERT INTO `requesicao` VALUES (26,1,1,81,'2009-03-02','0000-00-00',2),(25,1,1,53,'2009-02-13','0000-00-00',16);
/*!40000 ALTER TABLE `requesicao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `requesicao_log`
--

LOCK TABLES `requesicao_log` WRITE;
/*!40000 ALTER TABLE `requesicao_log` DISABLE KEYS */;
INSERT INTO `requesicao_log` VALUES (2,'a646745','Dr.Dre feat. Snoop Dogg-Still D.R.E. The Cronic 2001 uncesor','Disquete','2009-01-03','2009-01-02',32,'2009-02-09',2);
/*!40000 ALTER TABLE `requesicao_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_album`
--

LOCK TABLES `suport_album` WRITE;
/*!40000 ALTER TABLE `suport_album` DISABLE KEYS */;
INSERT INTO `suport_album` VALUES (15,'DVD'),(16,'Disquete');
/*!40000 ALTER TABLE `suport_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_filme`
--

LOCK TABLES `suport_filme` WRITE;
/*!40000 ALTER TABLE `suport_filme` DISABLE KEYS */;
INSERT INTO `suport_filme` VALUES (2,'DVD'),(3,'Bluray');
/*!40000 ALTER TABLE `suport_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_outro`
--

LOCK TABLES `suport_outro` WRITE;
/*!40000 ALTER TABLE `suport_outro` DISABLE KEYS */;
INSERT INTO `suport_outro` VALUES (1,'DVD'),(2,'CD');
/*!40000 ALTER TABLE `suport_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_som_filme`
--

LOCK TABLES `tipo_som_filme` WRITE;
/*!40000 ALTER TABLE `tipo_som_filme` DISABLE KEYS */;
INSERT INTO `tipo_som_filme` VALUES (3,'Dolby');
/*!40000 ALTER TABLE `tipo_som_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `topico`
--

LOCK TABLES `topico` WRITE;
/*!40000 ALTER TABLE `topico` DISABLE KEYS */;
INSERT INTO `topico` VALUES (1,2,42,1),(2,2,23,1),(4,2,2,1),(5,2,0,1),(6,2,3,1),(7,1,4,1),(8,1,11,1);
/*!40000 ALTER TABLE `topico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trilha_album`
--

LOCK TABLES `trilha_album` WRITE;
/*!40000 ALTER TABLE `trilha_album` DISABLE KEYS */;
INSERT INTO `trilha_album` VALUES (93,75,16,'Faixa 5','00:04:34','',0),(91,75,16,'Faixa 3','00:04:34','',0),(92,75,16,'Faixa 4','00:04:34','',0),(74,74,16,'Faixa 3','00:04:33','Muito bom.',1),(73,74,16,'Faixa 3','00:04:33','Muito bom.',2),(68,74,49,'Faixa 2','00:06:44','a',4),(75,74,16,'Faixa 3','00:04:33','Muito bom.',3),(90,75,51,'Faixa 2','00:04:34','',0),(89,75,51,'Faixa 1','00:04:34','Muito cooooooooooooooooooool.',1),(117,77,16,'I belive in miricles','00:03:33','Oi',1),(29,71,16,'Faixa2','00:04:33','',3),(100,71,16,'Faixa5','01:02:03','Muito bom!',4),(98,76,16,'dsd','34:35:34','sdfds',0),(116,77,16,'I belive in miricles','00:03:33','Oi',2),(109,71,16,'Faixa 4','00:06:00','',1),(106,71,16,'Hello','00:03:00','Hey!',2),(118,77,16,'Oi','00:04:55','',3),(119,53,16,'Olá','00:03:00','',2),(121,53,16,'Adeus','00:03:00','',1);
/*!40000 ALTER TABLE `trilha_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trilha_genero_album`
--

LOCK TABLES `trilha_genero_album` WRITE;
/*!40000 ALTER TABLE `trilha_genero_album` DISABLE KEYS */;
INSERT INTO `trilha_genero_album` VALUES (16,'POP'),(35,'Soul'),(50,'hey'),(51,'Clássica');
/*!40000 ALTER TABLE `trilha_genero_album` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-03-14 15:01:04
