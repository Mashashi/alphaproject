-- MySQL dump 10.11
--
-- Host: localhost    Database: alpha_project
-- ------------------------------------------------------
-- Server version	5.0.51b-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (8,'3232654545','asc','....',2000,0,0,0),(12,'etregeer','dfgdfg','A sua sinópse aqui...',2000,0,0,0);
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (1,'Dúvida, esclarecimentos, sugestões & novidades','<p></p>'),(2,'Bate-papo','<p></p>'),(3,'Matemática','<p></p>'),(4,'Português','<p></p>');
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bloco`
--

LOCK TABLES `bloco` WRITE;
/*!40000 ALTER TABLE `bloco` DISABLE KEYS */;
INSERT INTO `bloco` VALUES (19,1,'echo \"Vídeo biblioteca<hr />\n<object id=\\\"player1\\\" type=\\\"application/x-shockwave-flash\\\" \ndata=\\\"intro/player_flv_maxi.swf\\\" width=\\\"294\\\" height=\\\"276\\\">\n<noscript></noscript>\n<param name=\\\"movie\\\" value=\\\"intro/player_flv_maxi.swf\\\" />\n<param name=\\\"allowFullScreen\\\" value=\\\"true\\\" />\n<param name=\\\"FlashVars\\\" value=\\\"configxml=intro/video_biblioteca.xml\\\" />\n</object> \n<br />\n<a href=\\\"download.php?f=video_biblioteca.wmv\\\">Fazer download deste video</a>\";','2009-04-17 14:55:38','Vídeo biblioteca',1),(20,2,'echo \"Espaço Alpha<hr />\r\nBoas,<br />\r\n<p>Colega, professor ou docente. $benvindo</p>\";','2009-04-17 14:57:23','Saudações',1),(21,3,'$queryregnome = \"\";\r\n\r\n$regnome = \"\";\r\n\r\n$tit = \"\";\r\n\r\n$querynom = \"\";\r\n\r\n$bd = ligarBD();\r\n\r\n//Fazer a query que dara os cinco primeiros topicos mais recentes\r\n$querynum = $bd->submitQuery( \"\r\n	Select `id_topico`,`area_id_area` From `topico`, `post`\r\n	Where `id_topico` > \r\n	(Cast((Select Max(`id_topico`) From `topico`,`post` \r\n	Where `id_topico` = `topico_id_topico` And `post_activo` = 1 \r\n        And `post_prin` = 1) As Binary )-5) \r\n	And `id_topico` = `topico_id_topico` And `post_activo` = 1 And `post_prin` = 1 Order by `id_topico` Desc\" );	\r\n	\r\necho \"Tópicos Recentes<hr />\";\r\n\r\nfor ( $i = 0; $i < mysql_numrows($querynum); $i++ ){\r\n        \r\n	//Seleccionar os dados relativos ao post através\r\n	//da chave estrangeira do topico (topico_id_topico)\r\n	$querynom = $bd->submitQuery( \"Select `post_titulo`\r\n	,`registo_id_registo`,DATE_FORMAT(`post_data_hora`, \'%d-%m-%Y\') \r\n        From `post` Where `topico_id_topico` = \" \r\n        . mysql_result($querynum, $i, 0) .\" And `post_prin` = 1\" );\r\n\r\n	\r\n	if ( mysql_num_rows($querynom) > 0 )\r\n	{\r\n	\r\n		//Seleccionar dados relativos ao autor se o resultado da\r\n		//o número de registos sa $querynum for superior a 0\r\n		$queryregnome = $bd->submitQuery( \"\r\n		Select `registo_nick`,`id_registo` \r\n                From `registo` Where `id_registo` = \" \r\n                .mysql_result($querynom, 0, 1) );\r\n		\r\n		\r\n		if( mysql_num_rows($queryregnome) == 1 )\r\n			$link = \"?elem=10&amp;perfil=\" \r\n                       . mysql_result( $queryregnome, 0, 1 );	\r\n		else \r\n			$link = \"\"; \r\n		\r\n		//Data em que o tópico foi colocado\r\n		$data = mysql_result( $querynom, 0, 2 );\r\n		\r\n	}\r\n\r\n\r\n	if ( mysql_num_rows($queryregnome) == 1 )\r\n	{\r\n\r\n		//Se o número de colunas que \r\n                //tem como resultado $queryregnome for igual a\r\n		//1 o autor foi identificado correctamente\r\n		if ( $queryregnome ) \r\n		$regnome = \r\n                 \"<a href=\\\"$link\\\"><i>\"\r\n                 .mysql_result( $queryregnome, 0, 0 ).\"</i></a>\";\r\n		\r\n		mysql_freeresult( $queryregnome );\r\n		\r\n	}\r\n	else\r\n	{\r\n		//No caso de a condição a cima \r\n                //nao ser preenchida dar-se a, o autor como Bnido\r\n		$regnome = \"<em><b>Autor banido</b></em>\";\r\n		\r\n	}\r\n\r\n	$tit = mysql_result( $querynom, 0, 0 );\r\n\r\n	if ( strlen($tit) > 30 )\r\n		$tit = substr( $tit, 0, 30 ) . \"...\";\r\n\r\n	if ( mysql_numrows($querynom) > 0 )\r\n	{\r\n		\r\n		echo \"<div style=\\\"margin-top: 4px;\\\"><b>\r\n                <a href =\\\"?elem=8&amp;area=\" \r\n                . mysql_result( $querynum, $i, 1 ) .\r\n		\"&amp;topico=\" . mysql_result( $querynum, $i, 0 ) \r\n                . \"\\\">\" . $tit .\"</a></b><br /> por $regnome a <i>$data</i> \r\n		</div>\";\r\n\r\n	}\r\n	\r\n	/*if( mysql_num_rows($querynom) > 0 ){\r\n		mysql_freeresult($queryregnome);\r\n	}*/\r\n	\r\n	mysql_freeresult($querynom);\r\n	\r\n}\r\n\r\nmysql_freeresult($querynum);','2009-04-17 15:11:28','Tópicos recentes',1),(22,4,'	$elem_nome = \"\";\r\n		\r\n	$accao = \"\";\r\n		\r\n	$elem_url_nome = \"\";\r\n	\r\n	$bd = ligarBD();\r\n	\r\n	$query_req_most = $bd->submitQuery( \"\r\n	SELECT DISTINCT `id_geral`,`id_elemento`, COUNT( * ) AS Sum From `geral` Join `requesicao` On\r\n	`geral_id_geral` = `id_geral`\r\n	GROUP BY CRC32( `id_requesicao` )\r\n	ORDER BY sum DESC\r\n	LIMIT 0 , 5 \" );\r\n	\r\n	echo \"Mais requesitados<hr />\";\r\n			\r\n		\r\n			\r\n	//print_r( mysql_fetch_array($query_req_most) );\r\n	while($i < mysql_num_rows($query_req_most)){\r\n		\r\n		//for($i = 0; $i < mysql_num_rows($query_req_most); $i++)\r\n		\r\n		$i = mysql_num_rows($query_req_most);\r\n		\r\n		$id = mysql_result( $query_req_most, $i, 0 );\r\n		\r\n		$id_elem = mysql_result( $query_req_most, $i, 1 );\r\n	\r\n		switch ($id_elem){\r\n			\r\n			case 1: $elem_nome = \r\n                        $bd->submitQuery(\"Select `filme_nome` From `filme` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 5;\r\n				$elem_url_nome = \"filme\";\r\n			} else {\r\n				$elem_nome = \"<i>Filme não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			\r\n			break;\r\n			\r\n			\r\n			\r\n			case 2: \r\n			$elem_nome = \r\n                        $bd->submitQuery(\"Select `album_nome` From `album` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 7;\r\n				$elem_url_nome = \"album\";\r\n			} else {\r\n				$elem_nome = \"<i>Álbum não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			break;\r\n			\r\n			\r\n			\r\n			case 3: \r\n                        $elem_nome = \r\n                        $bd->submitQuery(\"Select `outro_nome` From `outro` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 9;\r\n				$elem_url_nome = \"outro\";\r\n			} else {\r\n				$elem_nome = \"<i>Outro item não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			break;\r\n			\r\n			\r\n			\r\n			default: $elem_nome = \"Sem correspondência\";\r\n			$accao = -1;\r\n			break;\r\n			\r\n			\r\n			\r\n		}\r\n		\r\n		//if( mysql_num_rows($query_req_most) > 0 ){\r\n			\r\n			if($accao > -1 && isset($_SESSION[\'id_user\']) ){\r\n				echo \"<div style=\\\"margin-top: 4px;\\\">\r\n				<a href=\\\"?elem=2&amp;accao=$accao&amp;$elem_url_nome=$id\\\">\r\n				\" . seeNomElem( $id_elem, true ) . \" \r\n				<b>$elem_nome</b></a>\r\n				 </div>\";		\r\n			} else {\r\n				echo \"<div style=\\\"margin-top: 4px;\\\">\r\n				\" . seeNomElem( $id_elem, true ) . \" \r\n				<b>$elem_nome</b>\r\n				 </div>\";	\r\n			}\r\n		//}\r\n		$i++;\r\n\r\n	}\r\n\r\nmysql_freeresult($query_req_most );\r\n	','2009-04-17 15:33:32','Mais requesitados',1),(23,5,'       $bd = ligarBD();\r\n	\r\n	$querynewelem = $bd->submitQuery(\"\r\n	Select * From `geral` Where `id_geral` >\r\n	( Cast( ( Select Max(`id_geral`) From `geral`) \r\n	As Binary )-5) Order By `id_geral` Desc\r\n	\");\r\n	\r\n	$id_elem = \"\";\r\n	\r\n	$id = \"\";\r\n	\r\n	$elem_nome = \"\";\r\n		\r\n	$accao = \"\";\r\n	\r\n	echo \"Novas aquisições da biblioteca<hr />\";\r\n	\r\n	$i = 0;\r\n	\r\n	while( $i < mysql_num_rows($querynewelem) ){\r\n		\r\n		\r\n	\r\n		$elem_nome = \"\";\r\n		\r\n		$accao = \"\";\r\n		\r\n		$elem_url_nome = \"\";\r\n		\r\n		$id = mysql_result( $querynewelem, $i, 0 );\r\n		\r\n		$id_elem = mysql_result( $querynewelem, $i, 1 );\r\n	\r\n		switch ($id_elem){\r\n			\r\n			case 1: $elem_nome = $bd->submitQuery(\"Select `filme_nome` From `filme` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 5;\r\n				$elem_url_nome = \"filme\";\r\n			} else {\r\n				$elem_nome = \"<i>Filme não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			\r\n			break;\r\n			\r\n			\r\n			\r\n			case 2: \r\n			$elem_nome = $bd->submitQuery(\"Select `album_nome` From `album` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 7;\r\n				$elem_url_nome = \"album\";\r\n			} else {\r\n				$elem_nome = \"<i>Álbum não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			break;\r\n			\r\n			\r\n			\r\n			case 3: $elem_nome = $bd->submitQuery(\"Select `outro_nome` From `outro` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 9;\r\n				$elem_url_nome = \"outro\";\r\n			} else {\r\n				$elem_nome = \"<i>Outro item não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			break;\r\n			\r\n			\r\n			\r\n			default: $elem_nome = \"Sem correspondência\";\r\n			$accao = -1;\r\n			break;\r\n			\r\n			\r\n			\r\n		}\r\n		\r\n		//if( mysql_num_rows($querynewelem) > 0 ){\r\n			\r\n			if($accao > -1 && isset($_SESSION[\'id_user\']) ){\r\n				echo \"<div style=\\\"margin-top: 4px;\\\">\r\n				<a href=\\\"?elem=2&amp;accao=$accao&amp;$elem_url_nome=$id\\\">\r\n				\" . seeNomElem( $id_elem, true ) . \" \r\n				<b>$elem_nome</b></a>\r\n				 </div>\";		\r\n			} else {\r\n				echo \"<div style=\\\"margin-top: 4px;\\\">\r\n				\" . seeNomElem( $id_elem, true ) . \" \r\n				<b>$elem_nome</b>\r\n				 </div>\";	\r\n			}\r\n		//}\r\n		\r\n		$i++;\r\n		\r\n	}	\r\n		\r\n		\r\n	mysql_freeresult($querynewelem);','2009-04-17 16:23:03','Novas aquisições da biblioteca',1),(24,6,'echo	\"Ver utilizadores<hr />\";\r\n\r\n$bd = ligarBD(); \r\n\r\n$querynom = $bd->submitQuery( \"Select `id_registo`, `registo_nick` From `registo` Where	`registo_online` Is Not Null Limit 0,9\" );\r\n\r\nif ( mysql_numrows($querynom) > 0 )\r\n{\r\n\r\n for ( $i = 0; $i < mysql_numrows($querynom); $i++  )\r\n {\r\n//Terá de se criar um documento para mostrar as informações relativas a um user\r\necho \"<a href=\\\"?elem=10&amp;perfil=\" . mysql_result( $querynom, 0, 0 ) . \"\\\">\r\n<font style=\\\"font-size: \" . rand( 10, 30 ) . \"px;font-variant: small-caps;\\\">\" . mysql_result( $querynom, $i, 1 ) .\"</font></a>\";\r\n}\r\n\r\n\r\n}\r\necho \"<table style=\\\"border: 1px solid black;\\\">\r\n<tr>\r\n<td>\r\n<a href=\\\"?elem=10\\\"><b>Todos</b></a>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<a href=\\\"?elem=10&amp;u=1\\\"><b>Online</b></a>\r\n</td>\r\n</tr>\r\n</table>\";\r\n\r\nmysql_freeresult($querynom);','2009-04-17 17:03:42','Ver utilizadores',1),(25,7,'echo \"Novos utilizadores<hr />\";\r\n\r\n$bd = ligarBD();\r\n\r\n$query = $bd->submitQuery( \"Select `id_registo`,`registo_nick`,\r\nDATE_FORMAT(`registo_data`, \'%d-%m-%Y\'),`registo_ass`\r\nFrom `registo` Where `id_registo` >= \r\n(Cast((Select Max(`id_registo`) From `registo`) As Binary )-4) \r\nOrder by `id_registo` Desc\" );\r\n\r\n$ass = \"\";\r\n\r\nfor ( $i = 0; $i < mysql_numrows($query); $i++ )\r\n{\r\n\r\n	$ass = mysql_result( $query, $i, 3 );\r\n\r\n	if ( $ass == null || strlen(trim($ass)) == 0 )\r\n		$ass = \"\";\r\n	else\r\n		$ass = \"<i>\" . $ass . \"</i><br/>\";\r\n\r\n	echo \"<div style=\\\"margin-top: 4px;\\\">\r\n       <a href=\\\"?elem=10&amp;perfil=\" . mysql_result( $query, $i, 0       ) . \"\\\"><b>\" . mysql_result( $query, $i, 1 ) . \"</b></a><br />\" .  $ass . \"Registado à <i>\" . mysql_result( $query, $i, 2 ) . \"</i></div>\";\r\n\r\n}\r\n\r\nmysql_freeresult($query);\r\n','2009-04-17 17:13:53','Novos utilizadores',1),(26,8,'echo \"Notícias<hr /><iframe src=\\\"feeds.php\\\" name=\\\"feeds\\\" frameborder=\\\"0\\\" height=\\\"200\\\"></iframe>\";','2009-04-17 17:21:07','Feeds de nótícias',0);
/*!40000 ALTER TABLE `bloco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `controlo_respeito`
--

LOCK TABLES `controlo_respeito` WRITE;
/*!40000 ALTER TABLE `controlo_respeito` DISABLE KEYS */;
INSERT INTO `controlo_respeito` VALUES (1,1,41,38,1,2,1,1);
/*!40000 ALTER TABLE `controlo_respeito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `controlo_votacao`
--

LOCK TABLES `controlo_votacao` WRITE;
/*!40000 ALTER TABLE `controlo_votacao` DISABLE KEYS */;
INSERT INTO `controlo_votacao` VALUES (1,1,1),(3,3,1);
/*!40000 ALTER TABLE `controlo_votacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_album`
--

LOCK TABLES `copi_album` WRITE;
/*!40000 ALTER TABLE `copi_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `copi_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_filme`
--

LOCK TABLES `copi_filme` WRITE;
/*!40000 ALTER TABLE `copi_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `copi_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_outro`
--

LOCK TABLES `copi_outro` WRITE;
/*!40000 ALTER TABLE `copi_outro` DISABLE KEYS */;
/*!40000 ALTER TABLE `copi_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `direito_outro`
--

LOCK TABLES `direito_outro` WRITE;
/*!40000 ALTER TABLE `direito_outro` DISABLE KEYS */;
INSERT INTO `direito_outro` VALUES (1,'GNU');
/*!40000 ALTER TABLE `direito_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `estatuto`
--

LOCK TABLES `estatuto` WRITE;
/*!40000 ALTER TABLE `estatuto` DISABLE KEYS */;
INSERT INTO `estatuto` VALUES (1,'Administrador',1,1,1,1,1,1,1,1,1,1,1,1,1),(2,'Professor',0,0,0,1,1,1,0,0,0,0,0,0,0),(3,'Aluno',0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `estatuto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` VALUES (1,'Esqueci-me da pass. \nO que faço?','Para modificares/recuperares a tua password, deves te dirigir a biblioteca e pedir para que uma nova te seja atribuida, ou a actual revelada. \n\nCaso a opção no menu de login \"Esqueci-me da minha password\", esteja activa, deves primariamente utilizar esse recurso.'),(2,'Quero imprimir um documento na biblioteca o que devo fazer?','Para imprimir um documento na biblioteca deves entrar na área de trabalho do Alunox que tem a password Eseq2008, em um dos PCs disponíveis, que se encontram configurados para o efeito.'),(3,'Como faço para obter uma conta?','Dirige-te, a bibliteca, pede o formulário em papel e deixa o pessoal docente encarregar-se do resto :D\n\nNo prazo de 1 a 4 dias, conforme a carga de trabalho, a tua conta vai ser criada.\n\nNão te esqueças de apresentar o cartão no acto!'),(4,'Qual é o periódo de funcionamento deste projecto? ','Podes aceder ao alphaproject, sensivelmente, apartir  das 9h00 até às 17h00.'),(5,'O que é que tem havido de novo no síte?','A introdução da possiblidade de criar tópicos sticky, isto para os gestores;\n\nA possiblidade de dares ou receberes respeito de um utilizador.'),(9,'Regras do síte e conselhos de boa utilização','Conselhos de utilização:\n* Sê cortez dentro da comunidade;\n* Procura escrever sobretudo em Português;\n* Sempre que enviares parte de um documento, reporta a fonte.\n\nRegras de utilização:\n* Não faças requesições de elementos que à partida sabes que não vais levantar;\n* Não praguejes;\n* Faz intervenções opurtunas.\n\nSanções a aplicar:\nEm caso de desrespeito por as regras desta identidade os utilizadores podem ser punidos desde apenas um aviso até, em último recurso, apelar-se ao conselho executico para que a sanção a executar seja mais adequada.');
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `filme`
--

LOCK TABLES `filme` WRITE;
/*!40000 ALTER TABLE `filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `frase`
--

LOCK TABLES `frase` WRITE;
/*!40000 ALTER TABLE `frase` DISABLE KEYS */;
INSERT INTO `frase` VALUES (1,'O conhecimento são coisas úteis e práticas'),(2,'Lembre-se, de que um ponta-pé na bunda é sempre um passo para frente'),(3,'Respeita a ti mesmo, e terás um carácter nobre');
/*!40000 ALTER TABLE `frase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `genero_filme`
--

LOCK TABLES `genero_filme` WRITE;
/*!40000 ALTER TABLE `genero_filme` DISABLE KEYS */;
INSERT INTO `genero_filme` VALUES (1,'Drama');
/*!40000 ALTER TABLE `genero_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `geral`
--

LOCK TABLES `geral` WRITE;
/*!40000 ALTER TABLE `geral` DISABLE KEYS */;
INSERT INTO `geral` VALUES (12,2);
/*!40000 ALTER TABLE `geral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `mensagem`
--

LOCK TABLES `mensagem` WRITE;
/*!40000 ALTER TABLE `mensagem` DISABLE KEYS */;
INSERT INTO `mensagem` VALUES (1,1,1,2,'2009-03-17 16:45:33','<p>Olá <b>Gomar</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(3,1,1,3,'2009-03-20 14:12:15','<p>Olá <b>Convidado</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(4,2,1,2,'2009-03-23 11:30:18','Encontram-se disponíveis as seguintes cópias: 8 em CD.<p>A sua requesição foi feita em 23/03/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 23-03-2009 para levantar o filme.\r\n		E aparir da data que levantar o filme tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 1.\r\n		Traga-o consigo a quando o levantamento e devolução do filme.\r\n		<a href=\"?elem=2&amp;accao=5&amp;filme=1\">\r\n		<b>Requesição do filme <u>Lista de schindler</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Lista de schindler</u>\"</a>\r\n		','[Filme] Lista de schindler'),(5,2,3,4,'2009-03-23 12:59:50','<p>Olá <b>Aluno1</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(6,2,3,5,'2009-03-23 13:09:34','<p>Olá <b>Aluno2</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(28,13,3,6,'2009-03-24 16:23:32','FEIO :D\n','das'),(29,13,3,6,'2009-03-24 16:23:34','FEIO :D\n','das'),(30,13,3,6,'2009-03-24 16:23:35','FEIO :D\n','das'),(31,13,3,6,'2009-03-24 16:23:36','FEIO :D\n','das'),(32,13,3,6,'2009-03-24 16:23:37','FEIO :D\n','das'),(33,6,3,11,'2009-03-24 16:24:35','olaAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAA<i></i>sdfsdfdsf<p></p>sdfsdfsdfds\nsfsdfsdf<code></code>','sdfsdf'),(34,13,3,6,'2009-03-24 16:25:30','feio\n\n\n\n\n\n\n\n\n\n\n\n\n','das'),(35,13,3,6,'2009-03-24 16:25:31','feio\n\n\n\n\n\n\n\n\n\n\n\n\n','das'),(36,6,3,13,'2009-03-24 16:25:31','feio é tu','xvcxcv'),(37,13,3,6,'2009-03-24 16:25:33','feio\n\n\n\n\n\n\n\n\n\n\n\n\n','das'),(38,13,3,6,'2009-03-24 16:25:34','feio\n\n\n\n\n\n\n\n\n\n\n\n\n','das'),(39,6,3,13,'2009-03-24 16:25:42','feio és tu','xvcxcv'),(40,6,3,13,'2009-03-24 16:25:43','feio és tu','xvcxcv'),(8,2,3,7,'2009-03-23 13:09:49','<p>Olá <b>Aluno4</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(9,2,3,8,'2009-03-23 13:09:56','<p>Olá <b>Aluno5</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(10,2,3,9,'2009-03-23 13:10:03','<p>Olá <b>Aluno6</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(11,2,3,10,'2009-03-23 13:10:10','<p>Olá <b>Aluno7</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(12,2,3,11,'2009-03-23 13:10:17','<p>Olá <b>Aluno8</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(13,2,3,12,'2009-03-23 13:10:24','<p>Olá <b>Aluno9</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(14,2,3,13,'2009-03-23 13:10:32','<p>Olá <b>Aluno10</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(15,2,3,14,'2009-03-23 13:10:39','<p>Olá <b>Aluno11</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(16,2,3,15,'2009-03-23 13:10:45','<p>Olá <b>Aluno12</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(17,2,3,16,'2009-03-23 13:10:52','<p>Olá <b>Aluno13</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(18,2,3,17,'2009-03-23 13:11:09','<p>Olá <b>Aluno14</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(19,2,3,18,'2009-03-23 13:11:16','<p>Olá <b>Aluno15</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(20,2,3,19,'2009-03-23 13:11:23','<p>Olá <b>Aluno16</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(21,2,3,20,'2009-03-23 13:11:30','<p>Olá <b>Aluno17</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(22,2,3,21,'2009-03-23 13:11:36','<p>Olá <b>Aluno18</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(23,2,3,22,'2009-03-23 13:11:42','<p>Olá <b>Aluno19</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(24,2,3,23,'2009-03-23 13:11:50','<p>Olá <b>Aluno20</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(25,1,1,1,'2009-03-23 14:39:09','Encontram-se disponíveis as seguintes cópias:  em CD-ROM.<p>A sua requesição foi feita em 23/03/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 28-03-2009 para levantar o álbum.\r\n		E aparir da data que levantar o álbum tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 2.\r\n		Traga-o consigo a quando o levantamento e devolução do álbum.\r\n		<a href=\"?elem=2&amp;accao=7&amp;album=10\">\r\n		<b>Requesição do álbum <u>Linking park</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Linking park</u>\"</a>\r\n		','[Álbum] Linking park'),(26,1,1,1,'2009-03-23 14:48:14','Encontram-se disponíveis as seguintes cópias:  em CD-ROM.<p>A sua requesição foi feita em 23/03/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 28-03-2009 para levantar o álbum.\r\n		E aparir da data que levantar o álbum tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 3.\r\n		Traga-o consigo a quando o levantamento e devolução do álbum.\r\n		<a href=\"?elem=2&amp;accao=7&amp;album=10\">\r\n		<b>Requesição do álbum <u>Linking park</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Linking park</u>\"</a>\r\n		','[Álbum] Linking park'),(27,2,1,2,'2009-03-23 14:49:00','Encontram-se disponíveis as seguintes cópias:  em CD-ROM.<p>A sua requesição foi feita em 23/03/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 25-03-2009 para levantar o álbum.\r\n		E aparir da data que levantar o álbum tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 4.\r\n		Traga-o consigo a quando o levantamento e devolução do álbum.\r\n		<a href=\"?elem=2&amp;accao=7&amp;album=10\">\r\n		<b>Requesição do álbum <u>Linking park</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Linking park</u>\"</a>\r\n		','[Álbum] Linking park'),(41,6,3,13,'2009-03-24 16:25:44','feio és tu','xvcxcv'),(42,6,3,13,'2009-03-24 16:25:45','feio és tu','xvcxcv'),(43,6,3,13,'2009-03-24 16:25:45','feio és tu','xvcxcv'),(44,6,3,13,'2009-03-24 16:25:46','feio és tu','xvcxcv'),(45,6,3,13,'2009-03-24 16:25:46','feio és tu','xvcxcv'),(46,6,3,13,'2009-03-24 16:25:47','feio és tu','xvcxcv'),(47,6,3,13,'2009-03-24 16:25:47','feio és tu','xvcxcv'),(48,6,3,13,'2009-03-24 16:25:48','feio és tu','xvcxcv'),(49,6,3,13,'2009-03-24 16:25:48','feio és tu','xvcxcv'),(50,6,3,13,'2009-03-24 16:25:48','feio és tu','xvcxcv'),(51,6,3,13,'2009-03-24 16:25:49','feio és tu','xvcxcv'),(52,6,3,13,'2009-03-24 16:25:51','feio és tu','xvcxcv'),(53,6,3,13,'2009-03-24 16:25:52','feio és tu','xvcxcv');
/*!40000 ALTER TABLE `mensagem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_album`
--

LOCK TABLES `num_suport_album` WRITE;
/*!40000 ALTER TABLE `num_suport_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `num_suport_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_filme`
--

LOCK TABLES `num_suport_filme` WRITE;
/*!40000 ALTER TABLE `num_suport_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `num_suport_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_outro`
--

LOCK TABLES `num_suport_outro` WRITE;
/*!40000 ALTER TABLE `num_suport_outro` DISABLE KEYS */;
/*!40000 ALTER TABLE `num_suport_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `outro`
--

LOCK TABLES `outro` WRITE;
/*!40000 ALTER TABLE `outro` DISABLE KEYS */;
/*!40000 ALTER TABLE `outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (41,2,1,38,1,'[Novidade] Classificação e respeito','2009-04-15 17:18:08',1,'\nAgora os utilizadores do site, podem classificar os posts e as mensagems dos outros utilizadores.\nA soma dos pontos da classificação, traduz-se em pontos de respeito para esse utilizador. :P',1),(40,2,1,37,1,'[Novidade] Tópicos permanentes (sticky)','2009-04-15 17:17:24',1,'\nAgora no alphaproject é possível acessar a tópicos permanente(<i>Sticky</i>)! \r\n\r\nIsto é numa dada área as mensagens de extrema importância dentro do tema que tratam, serão muito mais facilmente acessíveis, visto que mesmo que seja feita navegação entre o menu de paginação esses tópicos estarão sempre acessíveis. \r\n\r\nUsem e abusem :)\r\n\r\n',1);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `realizador_filme`
--

LOCK TABLES `realizador_filme` WRITE;
/*!40000 ALTER TABLE `realizador_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `realizador_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `registo`
--

LOCK TABLES `registo` WRITE;
/*!40000 ALTER TABLE `registo` DISABLE KEYS */;
INSERT INTO `registo` VALUES (1,1,'Admin','6c075ded6e5e2e7d658500cb79af9130d4b5bb1c','2008-09-20','1991-06-26','imagens/avatar/18.gif','','a19020','2009-04-17 14:02:43','','rafael_r.c@hotmail.com',1,'Rafael','Campos','0000-00-00',NULL),(2,1,'Gomar','maruk','2009-03-17','1990-09-17','imagens/avatar/75.gif',' ...','a18405','2009-04-17 15:35:59','','gosha_maryan@hotmail.com',0,'Maryan','Hoshko','0000-00-00','2009-04-17 17:38:21'),(3,3,'Convidado','1234','2009-03-20','2009-03-20','imagens/avatar/27.gif','','a1234','2009-04-15 16:46:21','','',0,'Convidado','Convidado','0000-00-00',NULL),(4,3,'Aluno1','Eseq2008','2009-03-23','2009-03-20','','','1','2009-03-25 09:31:40','','',0,'Default','Default','0000-00-00',NULL),(5,3,'Aluno2','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','2','2009-03-24 14:33:10','','',0,'Default','Default','0000-00-00',NULL),(6,3,'Aluno3','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','3','2009-03-24 16:25:58','','',0,'Default','Default','0000-00-00',NULL),(7,3,'Aluno4','244813299','2009-03-23','2009-03-20','imagens/avatar/61.gif',' ...','4','2009-03-24 16:59:58','','',0,'Default','Default','0000-00-00',NULL),(8,3,'Aluno5','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/66.gif',' ...','5','2009-03-24 16:59:35','','',0,'Default','Default','0000-00-00',NULL),(9,3,'Aluno6','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','6','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(10,3,'Aluno7','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','7','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(11,3,'Aluno8','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','8','2009-03-24 16:25:49','','',0,'Default','Default','0000-00-00',NULL),(12,3,'Aluno9','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','9','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(13,3,'Aluno10','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','10','2009-03-24 16:43:48','','',0,'Default','Default','0000-00-00',NULL),(14,3,'Aluno11','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','11','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(15,3,'Aluno12','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','12','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(16,3,'Aluno13','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','13','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(17,3,'Aluno14','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','14','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(18,3,'Aluno15','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','15','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(19,3,'Aluno16','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','16','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(20,3,'Aluno17','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','17','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(21,3,'Aluno18','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','18','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(22,3,'Aluno19','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','19','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL),(23,3,'Aluno20','Eseq2008','2009-03-23','2009-03-20','imagens/avatar/74.gif','','20','2009-03-23 00:00:00','','',0,'Default','Default','0000-00-00',NULL);
/*!40000 ALTER TABLE `registo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `requesicao`
--

LOCK TABLES `requesicao` WRITE;
/*!40000 ALTER TABLE `requesicao` DISABLE KEYS */;
/*!40000 ALTER TABLE `requesicao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `requesicao_log`
--

LOCK TABLES `requesicao_log` WRITE;
/*!40000 ALTER TABLE `requesicao_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `requesicao_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_album`
--

LOCK TABLES `suport_album` WRITE;
/*!40000 ALTER TABLE `suport_album` DISABLE KEYS */;
INSERT INTO `suport_album` VALUES (5,'CD-ROM');
/*!40000 ALTER TABLE `suport_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_filme`
--

LOCK TABLES `suport_filme` WRITE;
/*!40000 ALTER TABLE `suport_filme` DISABLE KEYS */;
INSERT INTO `suport_filme` VALUES (1,'CD');
/*!40000 ALTER TABLE `suport_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_outro`
--

LOCK TABLES `suport_outro` WRITE;
/*!40000 ALTER TABLE `suport_outro` DISABLE KEYS */;
INSERT INTO `suport_outro` VALUES (1,'CD');
/*!40000 ALTER TABLE `suport_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_som_filme`
--

LOCK TABLES `tipo_som_filme` WRITE;
/*!40000 ALTER TABLE `tipo_som_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_som_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `topico`
--

LOCK TABLES `topico` WRITE;
/*!40000 ALTER TABLE `topico` DISABLE KEYS */;
INSERT INTO `topico` VALUES (38,1,29,1,0),(37,1,8,1,0);
/*!40000 ALTER TABLE `topico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trilha_album`
--

LOCK TABLES `trilha_album` WRITE;
/*!40000 ALTER TABLE `trilha_album` DISABLE KEYS */;
INSERT INTO `trilha_album` VALUES (4,12,1,'faixa2','00:00:00','',2),(3,12,1,'faixa1','00:00:00','',1);
/*!40000 ALTER TABLE `trilha_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trilha_genero_album`
--

LOCK TABLES `trilha_genero_album` WRITE;
/*!40000 ALTER TABLE `trilha_genero_album` DISABLE KEYS */;
INSERT INTO `trilha_genero_album` VALUES (1,'Rock'),(2,'Coro');
/*!40000 ALTER TABLE `trilha_genero_album` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-04-20  8:20:03
