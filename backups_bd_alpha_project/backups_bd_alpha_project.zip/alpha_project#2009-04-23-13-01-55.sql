-- MySQL dump 10.11
--
-- Host: localhost    Database: alpha_project
-- ------------------------------------------------------
-- Server version	5.0.51b-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (8,'3232654545','asc','....',2000,0,0,0);
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (1,'Dúvida, esclarecimentos, sugestões & novidades','<p></p>'),(2,'Bate-papo','<p></p>'),(3,'Matemática','<p></p>'),(4,'Português','<p></p>');
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bloco`
--

LOCK TABLES `bloco` WRITE;
/*!40000 ALTER TABLE `bloco` DISABLE KEYS */;
INSERT INTO `bloco` VALUES (19,1,'echo \"\r\n<object id=\\\"player1\\\" type=\\\"application/x-shockwave-flash\\\" \r\ndata=\\\"intro/player_flv_maxi.swf\\\" width=\\\"294\\\" height=\\\"276\\\">\r\n<noscript></noscript>\r\n<param name=\\\"movie\\\" value=\\\"intro/player_flv_maxi.swf\\\" />\r\n<param name=\\\"allowFullScreen\\\" value=\\\"true\\\" />\r\n<param name=\\\"FlashVars\\\" value=\\\"configxml=intro/video_biblioteca.xml\\\" />\r\n</object> \r\n<br />\r\n<a href=\\\"download.php?f=video_biblioteca.wmv\\\">Fazer download deste video</a>\";','2009-04-17 14:55:38','Vídeo biblioteca',1),(20,2,'echo \"\r\nBoas,<br />\r\n<p>Colega, professor ou docente. $benvindo</p>\";','2009-04-17 14:57:23','Saudações',1),(21,3,'$queryregnome = \"\";\r\n\r\n$regnome = \"\";\r\n\r\n$tit = \"\";\r\n\r\n$querynom = \"\";\r\n\r\n$bd = ligarBD();\r\n\r\n//Fazer a query que dara os cinco primeiros topicos mais recentes\r\n$querynum = $bd->submitQuery( \"\r\n	Select `id_topico`,`area_id_area` From `topico`, `post`\r\n	Where `id_topico` > \r\n	(Cast((Select Max(`id_topico`) From `topico`,`post` \r\n	Where `id_topico` = `topico_id_topico` And `post_activo` = 1 \r\n        And `post_prin` = 1) As Binary )-5) \r\n	And `id_topico` = `topico_id_topico` And `post_activo` = 1 And `post_prin` = 1 Order by `id_topico` Desc\" );	\r\n\r\nfor ( $i = 0; $i < mysql_numrows($querynum); $i++ ){\r\n        \r\n	//Seleccionar os dados relativos ao post através\r\n	//da chave estrangeira do topico (topico_id_topico)\r\n	$querynom = $bd->submitQuery( \"Select `post_titulo`\r\n	,`registo_id_registo`,DATE_FORMAT(`post_data_hora`, \'%d-%m-%Y\') \r\n        From `post` Where `topico_id_topico` = \" \r\n        . mysql_result($querynum, $i, 0) .\" And `post_prin` = 1\" );\r\n\r\n	\r\n	if ( mysql_num_rows($querynom) > 0 )\r\n	{\r\n	\r\n		//Seleccionar dados relativos ao autor se o resultado da\r\n		//o número de registos sa $querynum for superior a 0\r\n		$queryregnome = $bd->submitQuery( \"\r\n		Select `registo_nick`,`id_registo` \r\n                From `registo` Where `id_registo` = \" \r\n                .mysql_result($querynom, 0, 1) );\r\n		\r\n		\r\n		if( mysql_num_rows($queryregnome) == 1 )\r\n			$link = \"?elem=10&amp;perfil=\" \r\n                       . mysql_result( $queryregnome, 0, 1 );	\r\n		else \r\n			$link = \"\"; \r\n		\r\n		//Data em que o tópico foi colocado\r\n		$data = mysql_result( $querynom, 0, 2 );\r\n		\r\n	}\r\n\r\n\r\n	if ( mysql_num_rows($queryregnome) == 1 )\r\n	{\r\n\r\n		//Se o número de colunas que \r\n                //tem como resultado $queryregnome for igual a\r\n		//1 o autor foi identificado correctamente\r\n		if ( $queryregnome ) \r\n		$regnome = \r\n                 \"<a href=\\\"$link\\\"><i>\"\r\n                 .mysql_result( $queryregnome, 0, 0 ).\"</i></a>\";\r\n		\r\n		mysql_freeresult( $queryregnome );\r\n		\r\n	}\r\n	else\r\n	{\r\n		//No caso de a condição a cima \r\n                //nao ser preenchida dar-se a, o autor como Bnido\r\n		$regnome = \"<em><b>Autor banido</b></em>\";\r\n		\r\n	}\r\n\r\n	$tit = mysql_result( $querynom, 0, 0 );\r\n\r\n	if ( strlen($tit) > 30 )\r\n		$tit = substr( $tit, 0, 30 ) . \"...\";\r\n\r\n	if ( mysql_numrows($querynom) > 0 )\r\n	{\r\n		\r\n		echo \"<div style=\\\"margin-top: 4px;\\\"><b>\r\n                <a href =\\\"?elem=8&amp;area=\" \r\n                . mysql_result( $querynum, $i, 1 ) .\r\n		\"&amp;topico=\" . mysql_result( $querynum, $i, 0 ) \r\n                . \"\\\">\" . $tit .\"</a></b><br /> por $regnome a <i>$data</i> \r\n		</div>\";\r\n\r\n	}\r\n	\r\n	/*if( mysql_num_rows($querynom) > 0 ){\r\n		mysql_freeresult($queryregnome);\r\n	}*/\r\n	\r\n	mysql_freeresult($querynom);\r\n	\r\n}\r\n\r\nmysql_freeresult($querynum);','2009-04-17 15:11:28','Tópicos recentes',1),(22,4,'	$elem_nome = \"\";\r\n		\r\n	$accao = \"\";\r\n		\r\n	$elem_url_nome = \"\";\r\n	\r\n	$bd = ligarBD();\r\n	\r\n	$query_req_most = $bd->submitQuery( \"\r\n	SELECT DISTINCT `id_geral`,`id_elemento`, COUNT( * ) \r\n        AS Sum From `geral` Join `requesicao` On\r\n	`geral_id_geral` = `id_geral`\r\n	GROUP BY CRC32( `id_requesicao` )\r\n	ORDER BY sum DESC\r\n	LIMIT 0 , 5 \" );\r\n				\r\n			\r\n	//print_r( mysql_fetch_array($query_req_most) );\r\n	while($i < mysql_num_rows($query_req_most)){\r\n		\r\n		//for($i = 0; $i < mysql_num_rows($query_req_most); $i++)\r\n		\r\n		$i = mysql_num_rows($query_req_most);\r\n		\r\n		$id = mysql_result( $query_req_most, $i, 0 );\r\n		\r\n		$id_elem = mysql_result( $query_req_most, $i, 1 );\r\n	\r\n		switch ($id_elem){\r\n			\r\n			case 1: $elem_nome = \r\n                        $bd->submitQuery(\"Select `filme_nome` From `filme` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 5;\r\n				$elem_url_nome = \"filme\";\r\n			} else {\r\n				$elem_nome = \"<i>Filme não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			\r\n			break;\r\n			\r\n			\r\n			\r\n			case 2: \r\n			$elem_nome = \r\n                        $bd->submitQuery(\"Select `album_nome` From `album` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 7;\r\n				$elem_url_nome = \"album\";\r\n			} else {\r\n				$elem_nome = \"<i>Álbum não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			break;\r\n			\r\n			\r\n			\r\n			case 3: \r\n                        $elem_nome = \r\n                        $bd->submitQuery(\"Select `outro_nome` From `outro` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 9;\r\n				$elem_url_nome = \"outro\";\r\n			} else {\r\n				$elem_nome = \"<i>Outro item não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			break;\r\n			\r\n			\r\n			\r\n			default: $elem_nome = \"Sem correspondência\";\r\n			$accao = -1;\r\n			break;\r\n			\r\n			\r\n			\r\n		}\r\n		\r\n		//if( mysql_num_rows($query_req_most) > 0 ){\r\n			\r\n			if($accao > -1 && isset($_SESSION[\'id_user\']) ){\r\n				echo \"<div style=\\\"margin-top: 4px;\\\">\r\n				<a href=\\\"?elem=2&amp;accao=$accao&amp;$elem_url_nome=$id\\\">\r\n				\" . seeNomElem( $id_elem, true ) . \" \r\n				<b>$elem_nome</b></a>\r\n				 </div>\";		\r\n			} else {\r\n				echo \"<div style=\\\"margin-top: 4px;\\\">\r\n				\" . seeNomElem( $id_elem, true ) . \" \r\n				<b>$elem_nome</b>\r\n				 </div>\";	\r\n			}\r\n		//}\r\n		$i++;\r\n\r\n	}\r\n\r\nmysql_freeresult($query_req_most );\r\n	','2009-04-17 15:33:32','Mais requesitados',1),(23,5,'       $bd = ligarBD();\r\n	\r\n	$querynewelem = $bd->submitQuery(\"\r\n	Select * From `geral` Where `id_geral` >\r\n	( Cast( ( Select Max(`id_geral`) From `geral`) \r\n	As Binary )-5) Order By `id_geral` Desc\r\n	\");\r\n	\r\n	$id_elem = \"\";\r\n	\r\n	$id = \"\";\r\n	\r\n	$elem_nome = \"\";\r\n		\r\n	$accao = \"\";\r\n	\r\n	$i = 0;\r\n	\r\n	while( $i < mysql_num_rows($querynewelem) ){\r\n		\r\n		\r\n	\r\n		$elem_nome = \"\";\r\n		\r\n		$accao = \"\";\r\n		\r\n		$elem_url_nome = \"\";\r\n		\r\n		$id = mysql_result( $querynewelem, $i, 0 );\r\n		\r\n		$id_elem = mysql_result( $querynewelem, $i, 1 );\r\n	\r\n		switch ($id_elem){\r\n			\r\n			case 1: $elem_nome = $bd->submitQuery(\"Select `filme_nome` From `filme` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 5;\r\n				$elem_url_nome = \"filme\";\r\n			} else {\r\n				$elem_nome = \"<i>Filme não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			\r\n			break;\r\n			\r\n			\r\n			\r\n			case 2: \r\n			$elem_nome = $bd->submitQuery(\"Select `album_nome` From `album` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 7;\r\n				$elem_url_nome = \"album\";\r\n			} else {\r\n				$elem_nome = \"<i>Álbum não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			break;\r\n			\r\n			\r\n			\r\n			case 3: $elem_nome = $bd->submitQuery(\"Select `outro_nome` From `outro` \r\n			Where `geral_id_geral` = $id\");\r\n			if( mysql_numrows($elem_nome) > 0 ){\r\n				$elem_nome = mysql_result($elem_nome,0,0);\r\n				$accao = 9;\r\n				$elem_url_nome = \"outro\";\r\n			} else {\r\n				$elem_nome = \"<i>Outro item não encontrado</i>\";\r\n				$accao = -1;\r\n			}\r\n			break;\r\n			\r\n			\r\n			\r\n			default: $elem_nome = \"Sem correspondência\";\r\n			$accao = -1;\r\n			break;\r\n			\r\n			\r\n			\r\n		}\r\n		\r\n		//if( mysql_num_rows($querynewelem) > 0 ){\r\n			\r\n			if($accao > -1 && isset($_SESSION[\'id_user\']) ){\r\n				echo \"<div style=\\\"margin-top: 4px;\\\">\r\n				<a href=\\\"?elem=2&amp;accao=$accao&amp;$elem_url_nome=$id\\\">\r\n				\" . seeNomElem( $id_elem, true ) . \" \r\n				<b>$elem_nome</b></a>\r\n				 </div>\";		\r\n			} else {\r\n				echo \"<div style=\\\"margin-top: 4px;\\\">\r\n				\" . seeNomElem( $id_elem, true ) . \" \r\n				<b>$elem_nome</b>\r\n				 </div>\";	\r\n			}\r\n		//}\r\n		\r\n		$i++;\r\n		\r\n	}	\r\n		\r\n		\r\n	mysql_freeresult($querynewelem);','2009-04-17 16:23:03','Novas aquisições da biblioteca',1),(24,6,'$bd = ligarBD(); \r\n\r\n$querynom = $bd->submitQuery( \"Select `id_registo`, `registo_nick` From `registo` Where	`registo_online` Is Not Null Limit 0,9\" );\r\n\r\nif ( mysql_numrows($querynom) > 0 )\r\n{\r\n\r\n for ( $i = 0; $i < mysql_numrows($querynom); $i++  )\r\n {\r\n//Terá de se criar um documento para mostrar as informações relativas a um user\r\necho \"<a href=\\\"?elem=10&perfil=\" . mysql_result( $querynom, 0, 0 ) . \"\\\">\r\n<font style=\\\"font-size: \" . rand( 10, 30 ) . \"px;font-variant: small-caps;\\\">\" . mysql_result( $querynom, $i, 1 ) .\"</font></a>\";\r\n}\r\n\r\n\r\n}\r\necho \"<table style=\\\"border: 1px solid black;\\\">\r\n<tr>\r\n<td>\r\n<a href=\\\"?elem=10\\\"><b>Todos</b></a>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<a href=\\\"?elem=10&u=1\\\"><b>Online</b></a>\r\n</td>\r\n</tr>\r\n</table>\";\r\n\r\nmysql_freeresult($querynom);\r\n\r\n\r\n\r\n\r','2009-04-22 12:59:36','Ver utilizadores\r\n\r\n\r\n\r\n\r',1),(25,7,'$bd = ligarBD();\r\n\r\n$query = $bd->submitQuery( \"Select `id_registo`,`registo_nick`,\r\nDATE_FORMAT(`registo_data`, \'%d-%m-%Y\'),`registo_ass`\r\nFrom `registo` Where `id_registo` >= \r\n(Cast((Select Max(`id_registo`) From `registo`) As Binary )-4) \r\nOrder by `id_registo` Desc\" );\r\n\r\n$ass = \"\";\r\n\r\nfor ( $i = 0; $i < mysql_numrows($query); $i++ )\r\n{\r\n\r\n	$ass = mysql_result( $query, $i, 3 );\r\n\r\n	if ( $ass == null || strlen(trim($ass)) == 0 )\r\n		$ass = \"\";\r\n	else\r\n		$ass = \"<i>\" . $ass . \"</i><br/>\";\r\n\r\n	echo \"<div style=\\\"margin-top: 4px;\\\">\r\n       <a href=\\\"?elem=10&amp;perfil=\" . mysql_result( $query, $i, 0       ) . \"\\\"><b>\" . mysql_result( $query, $i, 1 ) . \"</b></a><br />\" .  $ass . \"Registado à <i>\" . mysql_result( $query, $i, 2 ) . \"</i></div>\";\r\n\r\n}\r\n\r\nmysql_freeresult($query);\r\n','2009-04-17 17:13:53','Novos utilizadores',1),(26,8,'echo \"<iframe src=\\\"feeds.php\\\" name=\\\"feeds\\\" frameborder=\\\"0\\\" height=\\\"200\\\"></iframe>\";\r\n\r\n\r\n\r\n\r','2009-04-21 11:57:26','Feeds de nótícias\r\n\r\n\r\n\r\n\r',0);
/*!40000 ALTER TABLE `bloco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `controlo_respeito`
--

LOCK TABLES `controlo_respeito` WRITE;
/*!40000 ALTER TABLE `controlo_respeito` DISABLE KEYS */;
INSERT INTO `controlo_respeito` VALUES (1,1,41,38,1,2,1,1);
/*!40000 ALTER TABLE `controlo_respeito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `controlo_votacao`
--

LOCK TABLES `controlo_votacao` WRITE;
/*!40000 ALTER TABLE `controlo_votacao` DISABLE KEYS */;
INSERT INTO `controlo_votacao` VALUES (1,1,1),(1,2,13),(3,3,1);
/*!40000 ALTER TABLE `controlo_votacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_album`
--

LOCK TABLES `copi_album` WRITE;
/*!40000 ALTER TABLE `copi_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `copi_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_filme`
--

LOCK TABLES `copi_filme` WRITE;
/*!40000 ALTER TABLE `copi_filme` DISABLE KEYS */;
INSERT INTO `copi_filme` VALUES (0,15,0,2,1),(1,16,1,2,1),(2,17,1,2,1),(3,18,2,2,1),(3,19,1,2,1),(4,20,1,2,1),(1,22,1,2,1),(7,23,1,2,1),(1,24,1,2,1),(8,25,1,2,1),(9,26,1,2,1),(2,27,1,4,1),(10,28,1,2,1),(1,29,1,2,1),(1,30,1,2,1),(3,31,1,2,1),(11,32,1,2,1),(1,33,1,2,1),(9,34,1,2,1),(2,36,1,2,1);
/*!40000 ALTER TABLE `copi_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_outro`
--

LOCK TABLES `copi_outro` WRITE;
/*!40000 ALTER TABLE `copi_outro` DISABLE KEYS */;
INSERT INTO `copi_outro` VALUES (37,0,1,1);
/*!40000 ALTER TABLE `copi_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `direito_outro`
--

LOCK TABLES `direito_outro` WRITE;
/*!40000 ALTER TABLE `direito_outro` DISABLE KEYS */;
INSERT INTO `direito_outro` VALUES (1,'GNU');
/*!40000 ALTER TABLE `direito_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `estatuto`
--

LOCK TABLES `estatuto` WRITE;
/*!40000 ALTER TABLE `estatuto` DISABLE KEYS */;
INSERT INTO `estatuto` VALUES (1,'Administrador',1,1,1,1,1,1,1,1,1,1,1,1,1),(2,'Professor',0,0,0,1,1,1,0,0,0,0,0,0,0),(3,'Aluno',0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `estatuto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` VALUES (1,'Esqueci-me da pass. \nO que faço?','Para modificares/recuperares a tua password, deves te dirigir a biblioteca e pedir para que uma nova te seja atribuida, ou a actual revelada. \n\nCaso a opção no menu de login \"Esqueci-me da minha password\", esteja activa, deves primariamente utilizar esse recurso.'),(2,'Quero imprimir um documento na biblioteca o que devo fazer?','Para imprimir um documento na biblioteca deves entrar na área de trabalho do Alunox que tem a password Eseq2008, em um dos PCs disponíveis, que se encontram configurados para o efeito.'),(3,'Como faço para obter uma conta?','Dirige-te, a bibliteca, pede o formulário em papel e deixa o pessoal docente encarregar-se do resto :D\n\nNo prazo de 1 a 4 dias, conforme a carga de trabalho, a tua conta vai ser criada.\n\nNão te esqueças de apresentar o cartão no acto!'),(4,'Qual é o periódo de funcionamento deste projecto? ','Podes aceder ao alphaproject, sensivelmente, apartir  das 9h00 até às 17h00.'),(5,'O que é que tem havido de novo no síte?','A introdução da possiblidade de criar tópicos sticky, isto para os gestores;\n\nA possiblidade de dares ou receberes respeito de um utilizador.'),(9,'Regras do síte e conselhos de boa utilização','Conselhos de utilização:\n* Sê cortez dentro da comunidade;\n* Procura escrever sobretudo em Português;\n* Sempre que enviares parte de um documento, reporta a fonte.\n\nRegras de utilização:\n* Não faças requesições de elementos que à partida sabes que não vais levantar;\n* Não praguejes;\n* Faz intervenções opurtunas.\n\nSanções a aplicar:\nEm caso de desrespeito por as regras desta identidade os utilizadores podem ser punidos desde apenas um aviso até, em último recurso, apelar-se ao conselho executico para que a sanção a executar seja mais adequada.');
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `filme`
--

LOCK TABLES `filme` WRITE;
/*!40000 ALTER TABLE `filme` DISABLE KEYS */;
INSERT INTO `filme` VALUES (15,0,0,'','Temáticas da industrialização no Portugal contemporâneo (1830 - 1974)','','Uma história visual do fazer e dos saberes da Fábrica Robinson.\n\nMais informações no síte http://www.fundacaorobison.org/ via telefone 245 307 463 ou por e-mail fundrob@cm-portalegre.pt.',2007,0,0,0,0,0),(16,1,1,'','O Pianista','','<object data=\"http://www.youtube.com/v/itR0-I9idXk&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/itR0-I9idXk&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]itR0-I9idXk[/youtubecopy]-->\r\n\r\nAs memórias do pianista polonês Szpilman são retratadas nesse emocionante filme, contando como começaram as restrições aos judeus em Varsórvia e como conseguiu sobreviver ao Holocausto. Incrementado com cenas chocantes e belas músicas, o filme teve 7 indicações ao Oscar, incluindo o de Melhor Filme, levando para casa os importantes prêmios de Diretor, Ator e Roteiro Adaptado.\r\n\r\n',2002,142,8.5,0,0,0),(17,2,1,'','A verdade escondida','Era o marido perfeito até ela descobrir o que se escondia...','<object data=\"http://www.youtube.com/v/Vm4Fw2QElA4&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/Vm4Fw2QElA4&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]Vm4Fw2QElA4[/youtubecopy]-->\r\nPassaram alguns anos desde que o Dr. Norman traiu a sua mulher, Claire. Mas terminada a relação extra conjugal que Claire nunca soubera existir, a vida do casal parece um autêntico sonho. Entretanto, Claire começa a ouvir vozes misteriosas e a ter visões duma mulher dentro da sua casa..\r\n\r\nTitulo Original: What Lies Beneath\r\nTitulo Português: A Verdade Escondida',2000,0,6.5,0,0,0),(18,3,2,'','Canção de Lisboa','O primeiro filme Português feito por Portugueses','<object data=\"http://www.youtube.com/v/avcYEZGHp54&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/avcYEZGHp54&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]avcYEZGHp54[/youtubecopy]-->\n\nVasco Leitão (Vasco Santana), vive da mesada das tias, que vivem em Trás-os-Montes, que nunca vieram à capital, e o consideram um aluno cumpridor. Ora, o Vasco prefere os retiros e os arraiais, as cantigas populares e as mulheres bonitas, em particular Alice (Beatriz Costa), uma costureira do Bairro dos Castelinhos, o que não agrada ao pai, o alfaiate Caetano (António Silva), sabendo-o crivado de dívidas...\n\nOs azares de Vasco sucedem-se: no mesmo dia em que é reprovado no exame final de curso, recebe uma carta em que as tias lhe anunciam uma visita a Lisboa!\n\n',1933,91,7.9,0,0,0),(19,3,1,'','Os Irmãos Dalton','','<object data=\"http://www.youtube.com/v/Hwi_4bKpk7U&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/Hwi_4bKpk7U&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]Hwi_4bKpk7U[/youtubecopy]-->\n\nQuando os Dalton - os bandidos mais famosos do Faroeste - decidem assaltar um banco para agradar à mãe, as peripécias começam. Após uma tentativa de roubo frustada, os quatro irmãos fogem da prisão com o propósito de atravessar a fronteira mexicana em busca de um chapéu com poderes mágicos que lhes permitirá atingir os seus fins. Mas o percurso será turbulento e Lucky Luke está no seu encalço...\nBaseado nas personagens de BD mundialmente conhecidas das aventuras de Lucky Luke - criadas por Morris (Maurice de Bévère) e René Goscinny chega-nos uma hilariante comédia que presta homenagem aos dois autores.',2004,86,3,0,0,0),(20,4,1,'','Bounce','Um acaso com sentido','Buddy Amaral (Ben Affleck) sempre foi um vencedor... um homem de pessoas... um intimista. Enquanto sócio numa das mais agitadas e bem sucedidas agências de publicidade de Los Angeles, Buddy faz as coisas acontecerem. Destemido e confiante, e ferozmente encantador os seus clientes adoram-no. E graças ao seu charme arrebatador... as mulheres também. \r\n\r\nAo ver o seu vôo adiado, conhece no bar do aeroporto, outros dos passageiros que também esperam a chamada. Pensando estar a fazer uma boa acção, decide dar a sua vez a um deles, para que possa chegar a casa a tempo de acompanhar o filho numa actividade importante. Mas ao descobrir no dia seguinte, que o avião em que ele era suposto ir, tinha tido um acidente e não havia nenhum sobrevivente, fica mortificado e os remorsos intensificam o seu problema com o alcool, levando-o a uma clínica de desintoxicação durante 6 meses. Ao sair, decide procurar a viúva daquele passageiro, Abby Janello (Gwyneth Paltrow), uma dona de casa de um subúrbio de Los Angeles. Simples e com uma beleza natural, ela é uma mãe dedicada e uma amiga em quem confiar que leva uma vida simples, por quem se acaba por apaixonar perdidamente. \r\n\r\nDois estranhos em mundos completamente diferentes até que algo os aproximou. Algo mais que atracção. Algo mais que o destino. Algo mais que uma coincidência. ',2000,102,5.5,0,0,0),(21,1,1,'','O Fiel Jardineiro','','<object data=\"http://www.youtube.com/v/Pct2iEIzpVw&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/Pct2iEIzpVw&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]Pct2iEIzpVw[/youtubecopy]-->\r\n\r\nNuma zona remota a norte do Quénia, a brilhante e fervorosa activista Tessa Quayle (Rachel Weisz) é encontrada brutalmente assassinada. O seu companheiro de viagem, um médico local, desapareceu. Tudo indica tratar-se de um crime passional. Os membros do Alto Comissariado Britânico em Nairobi partem do princípio que o seu colega Justin Quayle (Ralph Fiennes), o marido de Tessa, pacato diplomata sem ambições, deixará o assunto ao cuidado deles. Não podiam estar mais enganados... Assombrado pelo remorso e revoltado pelos rumores sobre as infidelidades da sua mulher, Justin embarca numa perigosaodisseia sem fim para limpar o nome de Tessa; uma odisseia em busca da verdade que revelará uma conspiração a nível global.\r\nBaseado num best-seller de John Le Carré, O Fiel Jardineiro é um poderoso e comovente threller sobre o amor e a busca da verdade; um filme do galardoado realizador Fernando Meorelles (Cidade de Deus).\r\n\r\n',2005,123,7.7,0,0,0),(22,1,1,'','A Idade da Inocência','Num mundo de transição, numa idade de inocência, tiveram a coragem de quebrar as regras.','\r\n<object data=\"http://www.youtube.com/v/IZlI2fUm05U&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/IZlI2fUm05U&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]IZlI2fUm05U[/youtubecopy]-->\r\n\r\nMartin Scorsese, um dos maiores realizadores do nosso tempo, dirige o vencedor de um Oscar Daniel Day-Lewis (Melhor Actor de 1989, por O Meu Pé Esquerdo), Michelle Pfeiffer e Winona Ryder, numa brilhante adaptação do romance de Edith Wharton vencedor do Prémio Pulitzer. Um arrebatador romance sobre três abastados nova-iorquinos, apanhados num trágico triângulo amoroso que relata a grandeza e a hipocrisia da alta sociedade de 1870. No centro do filme está Newland Archer (Day-Lewis), um honesto advogado que anseia secretamente por uma vida mais apaixonante. Noivo da bela mas vulgar May Welland (Ryder), uma rapariga da sociedade, Newland está resignado com a sua vida. Mas quando uma prima de May chega de Nova Iorque, no meio de um escândalo social e sexual, Newland arrisca tudo em troca da possibilidade de um verdadeiro amor.',1993,133,7.1,0,0,0),(23,7,1,'','Pancho Villa','','<object data=\"http://www.youtube.com/v/9i73PBIjuP8&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/9i73PBIjuP8&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]9i73PBIjuP8[/youtubecopy]-->\r\n\r\nAntonio Banderas estrela essa incrível história que retrata como o revolucionário mexicano Pancho Villa permitiu que uma equipe de Holywood filmasse suas batalhas, alterando assim o curso da história do cinema e das guerras. A aventura começa quando os gigantes da aurora do cinema D.W. Griffith e Harry Aiken enviam o jovem executivo Frank Thayer ao México. O objetivo: comprar diretamente de Pancho Villa os direitos para filmar sua revolução. E o pior é que ele aceita. em meio fogo-cruzado, a equipe de Thayer arrisca sua vida nessa mistura de ficção e reallidade. Depois de muitas façanhas entre elas continuar vivos, Thayer e equipe conseguem fazer seu filme. Apesar da campanha contra Villa nos principais meios de comunicação norte-americanos, \"A Vida de General Villa\" é aclamado nos EUA. O filme altera a opinião pública e prova que \"a lente é mais poderosa que a espada\". ',2003,151,6.6,0,0,0),(24,1,1,'','Os condenados de shawshank','O medo pode aprisionar-te a esperança, liberta-te.','<object data=\"http://www.youtube.com/v/hWUfFwoe8ko&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/hWUfFwoe8ko&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]hWUfFwoe8ko[/youtubecopy]-->\r\n\r\nCom sete nomeações para os Óscares de Hollywood, incluindo as de Melhor Filme e de Melhor Actor (Morgan Freeman), \"The Shawshank Redemption\", entitulado em português \"Os Condenados de Shawshank\" não é exclusivamente mais uma adaptação para o cinema de um romance de Stephen King. É seguramente a melhor adaptações feita, tendo por base um romance deste autênctico fazedor de êxitos cinematográficos, e que a Academia decidiu considerar como um dos cinco melhores argumentos do ano.\r\nTim Robbins e Morgan Freeman formam em \"Os Condenados de Shawshank\" uma dupla de peso numa prisão de alta sefurança que reúne os maiores delinquentes dos Estados Unidos. Tim Robbins, um inocente por homicídio, era aparentemente o \"parvo\" que estaria sujeito a todas as investidas dos principais grupos de presos. Mas com algumas técnicas e com muita preseverança ele vai conseguir um lugar importante na escala hierárquica dos presos e da própria prisão. Entre silêncios e sussurros, gritos e situações de horror a vivência desta comunidade de presos é traçada em \"Os Condenados de Shawshank\" de uma forma sensível e com alguns toques de humor transformando este filme numa grande obra cinematográfica do ano.',1994,104,9.2,0,0,0),(25,8,1,'','A Marcha dos Pinguins',' A natureza inventou a mais bela das historias.','\r\n<object data=\"http://www.youtube.com/v/vNDc3-0gkew&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/vNDc3-0gkew&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]vNDc3-0gkew[/youtubecopy]-->\r\n\r\nTodos os Invernos, nos implacáveis desertos de gelo da Antártida, bem longe no local mais inóspito ao cimo da Terra, tem lugar uma viagem verdadeiramente extraordinária, efectuada da mesma forma há milénios. Pinguins Imperadores, aos milhares, abandonam a segurança das águas de azul cristalino onde habitam, e trepam para a superfície gelada, para dar início à sua longa jornada para uma região tão erma e tão extrema que não alberga nenhuma outra forma de vida, nesta época do ano. \r\n\r\nEm fila indiana, os pinguins marcham cegos pelas tempestades de neve, feridos pela força das rajadas de vento. Resolutos, indómitos, levados pela irresistível necessidade de se reproduzir, para assegurar a sobrevivência da espécie. Guiados pelo instinto, por uma força quase sobrenatural, dirigem-se sem falhar para o seu tradicional local de reprodução onde %u2013 após um ritual de complexas danças e delicados movimentos, acompanhados por uma cacofonia de arrebatadas canções %u2013 juntam-se em casais monógamos e acasalam. \r\n\r\nMas a história não fica por aqui...',2005,82,7.8,0,0,0),(26,9,1,'','Pressão máxima','Só um homem tem a destreza para anular um desastre nuclear.','<object data=\"http://www.youtube.com/v/ClxBL8zwTfg&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/ClxBL8zwTfg&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]ClxBL8zwTfg[/youtubecopy]-->\n\nMike Jeffers (TREAT WILLIAMS) é um segurança em vias de perder o emprego, devido à empresa nuclear onde trabalha estar prestes a ser encerrad. Os últimos dias de funções envolvem conduzir o senador estatal e o seu assistente numa visita interna às instalações, juntamente com toda a imprensa.\nSem o conhecimento de Mike, Samson (UDO KIER), um terrorista internacional, planeia o perigoso golpe de se introduzir no laboratório e roubar os componentes para criar uma bomba nuclear.\nTodos os membros da imprensa são mortos e a Mike é incutida a missão de proteger o senador e o seu assistente das mãos dos terroristas, ao mesmo tempo, que tem de conduzir a bomba nuclear para um local onde possa ser destruída.\nUma missão de Pressão Máxima.',2000,92,3.7,0,0,0),(27,2,1,'','Seven','7 pecados mortais','<object data=\"http://www.youtube.com/v/7fAf4wmN8Bw&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/7fAf4wmN8Bw&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]7fAf4wmN8Bw[/youtubecopy]-->\r\n\r\nBrad Pitt (\"Clube de Combate\") e o nomeado para um Óscar de Academia Morgan Freeman (\"Os Condenados de Shawshank\") protagonizam, neste misterioso thriller, o papel de dois detectives de homicídios que têm por missão resolver um puzzle de crimes baseados nos 7 Pecados Mortais - gula, luxúria, ganância, preguiça, vaidade, inveja e ira.\r\nO realizador David Fincher (\"O Jogo\") fez de SE7EN um poderoso e inesquecível filme que revela as profundezas da mente perturbada de um serial killer.',1995,125,8.6,0,0,0),(28,10,1,'','Frida','Prepare-se para ser reduzido.','<object data=\"http://www.youtube.com/v/ow-fscLTnZU&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/ow-fscLTnZU&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]ow-fscLTnZU[/youtubecopy]-->\r\n\r\nBaseado na biografia da pintora mexicana Frida Kahlo, o filme enfoca a vida amorosa da artista (aqui vivida por Salma Hayek). Desde seu casamento aberto com Diego Rivera (Alfred Molina), com quem revolucionou o mundo das artes - especialmente a mexicana -; passando por seu controverso caso com o político Leon Trotsky (Geoffrey Rush); e culminando nos seus provocantes romances com mulheres. No México, o trabalho de Julie Taymor causou polêmica e desagradou aos críticos.',2002,118,7.4,0,0,0),(29,1,1,'','A Domadora de Baleias','','<object data=\"http://www.youtube.com/v/fE7-_Z03Aw4&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/fE7-_Z03Aw4&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]fE7-_Z03Aw4[/youtubecopy]-->\r\n\r\nNuma pequena aldeia costeira da Nova Zelândia, o título de Grande Chefe vai passando de geração para geração, numa tradição que dura há mais de mil anos.\r\nPorourangi, o sucessor do actual Grande Chefe, tem dois gémeos: um rapaz que morre com a mãe à nascença, e uma rapariga, Pai, que sobrevive. Abalado com a tragédia, Porourangi parte para a Alemanha e deixa a filha entregue ao avô, Koro, o Grande Chefe.\r\nPassados 12 anos, Porourangi regressa a casa e recusa o seu destino, o de suceder a Koro que, cego pelo preconceito, não se convence que Pai é a natural herdeira. Koro manda então chamar todos os rapazes de 12 anos para tentar encontrar um novo líder.\r\nMas é entretanto, do fundo do oceano que vem a resposta. As baleias e Pai, preparam-se para encontrar o seu destino conjunto. Vencedor dos Prémios do Público nos Festivais de Sundance e Toronto, e nomeada para o Óscar® de Melhor Actriz (Keisha Castle-Hughes), A Domadora de Baleias é um filme mágico para ser descoberto por toda a família.',2002,98,7.7,0,0,0),(30,1,1,'','O Aviador','','<object data=\"http://www.youtube.com/v/I6QAM6LunXc&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/I6QAM6LunXc&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]I6QAM6LunXc[/youtubecopy]-->\r\n\r\nO Aviador é o excêntrico milionário industrial Howard Hughes (DiCaprio). Herdeiro de uma empresa de ferramentas petrolíferas, muda-se para Hollywood, onde a sua fama oscila entre os filmes que realiza e produz %u2013 por exemplo, Hell%u2019s Angels (1930) e Scarface (1932) %u2013 e o seu envolvimento quase compulsivo com diversas das mais belas mulheres do cinema %u2013 Katharine Hupburn (Blanchett) e Ava Gardner (Beckinsdale) são apenas duas. Mas, situado entre os anos 1920s e os 1940s, o filme centra-se sobretudo no seu fascínio pela aviação, à qual dedica boa parte da sua fortuna, do seu tempo e da sua sanidade mental; e à sua luta contra as suas debilidades físicas como a surdez e as fobias relacionadas com a limpeza, incutidas desde cedo por uma mãe super-protectora, e culminando num comportamento obsessivo-compulsivo que o levou ao isolamento.',2004,163,7.6,0,0,0),(31,3,1,'','Emma','','<object data=\"http://www.youtube.com/v/6WpLozLqLZ0&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/6WpLozLqLZ0&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]6WpLozLqLZ0[/youtubecopy]-->\r\n\r\nJovem bonita e inteligente, que vive com o pai viúvo, começa a sentir um vazio quando a governanta se casa. Ela resolve bancar o cupido para as pessoas que a cercam, na tentativa de tornar todas felizes como ela. Baseado em romance de Jane Austen.',1996,116,6.8,0,0,0),(32,11,1,'','Doutor Jivago','','<object data=\"http://www.youtube.com/v/wAWrXTn5Www&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/wAWrXTn5Www&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]wAWrXTn5Www[/youtubecopy]-->\r\n\r\nA Revolução Russa de 1917 serve como pano de fundo para a história de amor entre um jovem médico aristocrata e uma plebéia. Dirigido por David Lean (Lawrence da Arábia) e com Omar Sharif, Julie Christie, Geraldine Chaplin e Alec Guiness no elenco. Vencedor de 5 Oscars.\r\n',1965,192,8,0,0,0),(33,1,1,'','O Clube do Imperador','','<object data=\"http://www.youtube.com/v/FGmK59lqRWo&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/FGmK59lqRWo&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]FGmK59lqRWo[/youtubecopy]-->\r\n\r\nWilliam Hundert (Kevin Kline) é um professor, verdadeiramente apaixonado pelo seu trabalho, que crê firmemente que a vida de um cidadão deve ser regida por princípios de integridade.\r\nEsta é a mensagem que tenta transmitir aos seus alunos. Contudo, o seu método de ensino vai ser posto à prova por um novo aluno, Sedgewick Bell (Emile Hirsh), filho de um Senador, que entra em confronto directo com o professor e tenta arrastar os colegas nos seu actos de rebeldia. O desafio a que Hundert se propõe é modificar o carácter rebelde de Sedgewick, e ganhar a sua confiança...',2002,95,6.7,0,0,0),(34,9,1,'','Assalto ao Arranha-céus','40 andares de pura aventura','<object data=\"http://www.youtube.com/v/na6oY90tfpw&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/na6oY90tfpw&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]na6oY90tfpw[/youtubecopy]-->\r\n\r\nNo Natal,o policial nova-iorquino John McClane (Bruce Willis) vai visitar a mulher, Holly Gennero em Los Angeles.Lá,vai para uma festa em seu local de trabalho,a Nakatomi Plaza,uma gigantesca multinacional.Mas quando ele está lá, terroristas alemães liderados por Hans Gruber (Alan Rickman) e Ernst Gruber (Bill Pasold) seqüestram o prédio pretendendo roubar US$600.000.000,00 em ações. Só John McClane pode combater os terroristas.',1988,155,8.3,0,0,0),(36,2,1,'','Traffic','Ninguém sai ileso','<object data=\"http://www.youtube.com/v/hTz0mbQ0oW0&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" type=\"application/x-shockwave-flash\" width=\"419\" height=\"350\">\r\n<param name=\"quality\" value=\"high\" />\r\n<param name=\"allowFullScreen\" value=\"true\" />\r\n<param name=\"movie\" value=\"http://www.youtube.com/v/hTz0mbQ0oW0&hl=en&fs=1&rel=0&color1=0xe1600f&color2=0xfebd01\" />\r\n<img border=\"0\" src=\"/img/video.png\" alt=\"Vídeo (Objeto multimídia)\" /></object><!--[youtubecopy]hTz0mbQ0oW0[/youtubecopy]-->\r\n\r\nPor meio de três histórias que se cruzam, Traffic mostra o problema das drogas por diferentes ângulos. No México, o policial Javier Rodriguez (Benicio Del Toro) trabalha na região da fronteira com os EUA, tentando combater o tráfico. Ele resiste às tentações de dinheiro e poder, mas a corrupção que o cerca está sufocando-o. Nos Estados Unidos, em Ohio, Robert Wakefield (Michael Douglas) é nomeado o novo chefe do combate aos narcóticos no país. Porém, em casa, ele tem que lidar com a filha que está viciada em drogas. Em San Diego, o traficante Carlos Alaya (Steven Bauer) é preso e sua esposa (Catherine Zeta-Jones), para proteger os filhos, não vê outra saida senão tomar as rédeas do negócio. Baseado numa minissérie da TV britânica Channel 4.',2001,147,7.8,0,0,0);
/*!40000 ALTER TABLE `filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `frase`
--

LOCK TABLES `frase` WRITE;
/*!40000 ALTER TABLE `frase` DISABLE KEYS */;
INSERT INTO `frase` VALUES (1,'O conhecimento são coisas úteis e práticas'),(2,'Lembre-se, de que um ponta-pé na bunda é sempre um passo para frente'),(3,'Respeita a ti mesmo, e terás um carácter nobre');
/*!40000 ALTER TABLE `frase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `genero_filme`
--

LOCK TABLES `genero_filme` WRITE;
/*!40000 ALTER TABLE `genero_filme` DISABLE KEYS */;
INSERT INTO `genero_filme` VALUES (1,'Drama'),(2,'Thriller'),(3,'Comédia'),(4,'Romance'),(7,'Aventura'),(8,'Documentário'),(9,'Acção'),(10,'Biografia'),(11,'Épico');
/*!40000 ALTER TABLE `genero_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `geral`
--

LOCK TABLES `geral` WRITE;
/*!40000 ALTER TABLE `geral` DISABLE KEYS */;
INSERT INTO `geral` VALUES (16,1),(19,1),(18,1),(20,1),(17,1),(15,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(37,3),(36,1);
/*!40000 ALTER TABLE `geral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `mensagem`
--

LOCK TABLES `mensagem` WRITE;
/*!40000 ALTER TABLE `mensagem` DISABLE KEYS */;
INSERT INTO `mensagem` VALUES (1,1,1,2,'2009-03-17 16:45:33','<p>Olá <b>Gomar</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(3,1,1,3,'2009-03-20 14:12:15','<p>Olá <b>Convidado</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requesição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:administrador@megamail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(4,2,1,2,'2009-03-23 11:30:18','Encontram-se disponíveis as seguintes cópias: 8 em CD.<p>A sua requesição foi feita em 23/03/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 23-03-2009 para levantar o filme.\r\n		E aparir da data que levantar o filme tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 1.\r\n		Traga-o consigo a quando o levantamento e devolução do filme.\r\n		<a href=\"?elem=2&amp;accao=5&amp;filme=1\">\r\n		<b>Requesição do filme <u>Lista de schindler</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Lista de schindler</u>\"</a>\r\n		','[Filme] Lista de schindler'),(64,2,1,28,'2009-04-22 14:22:46','<p>Olá <b>BEBUXA19</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requisição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:rafael_r.c@hotmail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(65,2,1,29,'2009-04-22 14:26:45','<p>Olá <b>Kiduxa22Fox</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requisição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:rafael_r.c@hotmail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(66,2,1,30,'2009-04-22 14:28:08','<p>Olá <b>Nucha</b>...</p>\r\n			Temos o prazer de anunciar uma nova página\r\n			na história da biblioteca da Eça de Queirós, o síte Alpha Project tem \r\n			como missão ser o teu melhor amigo no que toca na consulta e \r\n			requisição de filmes, álbuns, ou outros materiais didáticos.</p>\r\n			\r\n			<p>Este não só é um espaço para te pores a par das novidades na \r\n			biblioteca Eça, mas também para trocares impressões dentro da \r\n			comunidade escolar, para isso sente-te\r\n			à vontade na utilização do fórum.</p>\r\n			<p>Por favor, afim de evitar problemas e \r\n			perguntas despropositadas consulta as FAQ \r\n			(as questões que são feitas com mais frequência).</p>\r\n			<i>Para mais questões sobre a utilização devida do síte consulta as FAQ \r\n			ou <a href=\"mailto:rafael_r.c@hotmail.com\">contacta o administrador.</a></i>','Se benvindo! :)'),(25,1,1,1,'2009-03-23 14:39:09','Encontram-se disponíveis as seguintes cópias:  em CD-ROM.<p>A sua requesição foi feita em 23/03/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 28-03-2009 para levantar o álbum.\r\n		E aparir da data que levantar o álbum tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 2.\r\n		Traga-o consigo a quando o levantamento e devolução do álbum.\r\n		<a href=\"?elem=2&amp;accao=7&amp;album=10\">\r\n		<b>Requesição do álbum <u>Linking park</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Linking park</u>\"</a>\r\n		','[Álbum] Linking park'),(26,1,1,1,'2009-03-23 14:48:14','Encontram-se disponíveis as seguintes cópias:  em CD-ROM.<p>A sua requesição foi feita em 23/03/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 28-03-2009 para levantar o álbum.\r\n		E aparir da data que levantar o álbum tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 3.\r\n		Traga-o consigo a quando o levantamento e devolução do álbum.\r\n		<a href=\"?elem=2&amp;accao=7&amp;album=10\">\r\n		<b>Requesição do álbum <u>Linking park</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Linking park</u>\"</a>\r\n		','[Álbum] Linking park'),(27,2,1,2,'2009-03-23 14:49:00','Encontram-se disponíveis as seguintes cópias:  em CD-ROM.<p>A sua requesição foi feita em 23/03/2009.</p>\r\n		\r\n		<p>Tem 5 dias apartir da data pretendida 25-03-2009 para levantar o álbum.\r\n		E aparir da data que levantar o álbum tem 5 dias para o entregar.</p>\r\n		\r\n		O ID da sua requesição é o 4.\r\n		Traga-o consigo a quando o levantamento e devolução do álbum.\r\n		<a href=\"?elem=2&amp;accao=7&amp;album=10\">\r\n		<b>Requesição do álbum <u>Linking park</u> feita com sucesso</b>\r\n		Clique aqui para visualizar a descrição de \"<u>Linking park</u>\"</a>\r\n		','[Álbum] Linking park'),(63,2,1,2,'2009-04-22 12:57:09','Olá+++++','Olá++++');
/*!40000 ALTER TABLE `mensagem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_album`
--

LOCK TABLES `num_suport_album` WRITE;
/*!40000 ALTER TABLE `num_suport_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `num_suport_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_filme`
--

LOCK TABLES `num_suport_filme` WRITE;
/*!40000 ALTER TABLE `num_suport_filme` DISABLE KEYS */;
INSERT INTO `num_suport_filme` VALUES ('A',15,0,0,2),('A',16,1,1,2),('A',17,2,1,2),('A',18,3,2,2),('A',19,3,1,2),('A',20,4,1,2),('A',22,1,1,2),('A',23,7,1,2),('A',24,1,1,2),('A',25,8,1,2),('A',26,9,1,2),('A',27,2,1,4),('A',28,10,1,2),('A',29,1,1,2),('A',30,1,1,2),('A',31,3,1,2),('B',32,11,1,2),('A',33,1,1,2),('A',34,9,1,2),('A',36,2,1,2);
/*!40000 ALTER TABLE `num_suport_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_outro`
--

LOCK TABLES `num_suport_outro` WRITE;
/*!40000 ALTER TABLE `num_suport_outro` DISABLE KEYS */;
INSERT INTO `num_suport_outro` VALUES (37,'A',0,1);
/*!40000 ALTER TABLE `num_suport_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `outro`
--

LOCK TABLES `outro` WRITE;
/*!40000 ALTER TABLE `outro` DISABLE KEYS */;
INSERT INTO `outro` VALUES (37,0,'Manual Virtual do Professor 8º Ano','Planeta vivo - sustentabilidade na terra.\r\nCiência naturais.\r\n\r\nPorto Editora',2006,0,'',0,0);
/*!40000 ALTER TABLE `outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (41,2,1,38,1,'[Novidade] Classificação e respeito','2009-04-15 17:18:08',1,'\nAgora os utilizadores do site, podem classificar os posts e as mensagems dos outros utilizadores.\nA soma dos pontos da classificação, traduz-se em pontos de respeito para esse utilizador. :P',1),(40,2,1,37,1,'[Novidade] Tópicos permanentes (sticky)','2009-04-15 17:17:24',1,'\nAgora no alphaproject é possível acessar a tópicos permanente(<i>Sticky</i>)! \r\n\r\nIsto é numa dada área as mensagens de extrema importância dentro do tema que tratam, serão muito mais facilmente acessíveis, visto que mesmo que seja feita navegação entre o menu de paginação esses tópicos estarão sempre acessíveis. \r\n\r\nUsem e abusem :)\r\n\r\n',1);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `realizador_filme`
--

LOCK TABLES `realizador_filme` WRITE;
/*!40000 ALTER TABLE `realizador_filme` DISABLE KEYS */;
INSERT INTO `realizador_filme` VALUES (2,1,16,1,' Roman Polanski'),(3,2,17,1,' Robert Zemeckis'),(5,3,18,2,' Cottinelli Telmo'),(8,3,19,1,' Philippe Haïm'),(9,4,20,1,' Michael Besman'),(10,4,20,1,' Steven Golin'),(11,1,21,1,' Fernando Meirelles'),(12,1,22,1,' Martin Scorsese'),(13,7,23,1,' Bruce Beresford'),(14,1,24,1,' Bruce Beresford'),(15,8,25,1,' Luc Jacquet'),(18,9,26,1,' Fred Olen Ray'),(17,2,27,1,' David Fincher'),(19,10,28,1,' Julie Taymor'),(20,1,29,1,' Niki Caro'),(21,1,30,1,' Martin Scorsese'),(22,3,31,1,' Douglas McGrath'),(23,11,32,1,' David Lean'),(24,1,33,1,' Michael Hoffman'),(25,9,34,1,' John McTiernan'),(27,2,36,1,' Steven Soderbergh');
/*!40000 ALTER TABLE `realizador_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `registo`
--

LOCK TABLES `registo` WRITE;
/*!40000 ALTER TABLE `registo` DISABLE KEYS */;
INSERT INTO `registo` VALUES (1,1,'Admin','6c075ded6e5e2e7d658500cb79af9130d4b5bb1c','2008-09-20','1991-06-26','imagens/avatar/18.gif','','a19020','2009-04-17 14:02:43','','rafael_r.c@hotmail.com',1,'Rafael','Campos','0000-00-00',NULL),(2,1,'Gomar','maruk','2009-03-17','1990-09-17','imagens/avatar/75.gif','...','a18405','2009-04-23 11:18:13','','gosha_maryan@hotmail.com',0,'Maryan','Hoshko','0000-00-00','2009-04-23 13:04:25'),(3,3,'Convidado','1234','2009-03-20','2009-03-20','imagens/avatar/27.gif','','a1234','2009-04-15 16:46:21','','',0,'Convidado','Convidado','0000-00-00',NULL),(28,3,'BEBUXA19','Fifa540','2009-04-22','1989-11-29','imagens/avatar/60.gif','','a19384','2009-04-22 00:00:00','','',0,'Solange','Francisco','0000-00-00',NULL),(29,3,'Kiduxa22Fox','Seidi969986Fox','2009-04-22','1986-08-16','imagens/avatar/61.gif','','a19434','2009-04-22 00:00:00','','',0,'Célia','Seidi','0000-00-00',NULL),(30,3,'Nucha','Polguinha','2009-04-22','1985-04-09','imagens/avatar/55.gif','','a19417','2009-04-22 00:00:00','','',0,'Maria','Fátima','0000-00-00',NULL);
/*!40000 ALTER TABLE `registo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `requesicao`
--

LOCK TABLES `requesicao` WRITE;
/*!40000 ALTER TABLE `requesicao` DISABLE KEYS */;
/*!40000 ALTER TABLE `requesicao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `requesicao_log`
--

LOCK TABLES `requesicao_log` WRITE;
/*!40000 ALTER TABLE `requesicao_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `requesicao_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `session_control`
--

LOCK TABLES `session_control` WRITE;
/*!40000 ALTER TABLE `session_control` DISABLE KEYS */;
INSERT INTO `session_control` VALUES ('ef9302a739c109cf7f318e74917a3c81e6d2e9f2',2,1);
/*!40000 ALTER TABLE `session_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_album`
--

LOCK TABLES `suport_album` WRITE;
/*!40000 ALTER TABLE `suport_album` DISABLE KEYS */;
INSERT INTO `suport_album` VALUES (5,'CD-ROM');
/*!40000 ALTER TABLE `suport_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_filme`
--

LOCK TABLES `suport_filme` WRITE;
/*!40000 ALTER TABLE `suport_filme` DISABLE KEYS */;
INSERT INTO `suport_filme` VALUES (2,'DVD');
/*!40000 ALTER TABLE `suport_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_outro`
--

LOCK TABLES `suport_outro` WRITE;
/*!40000 ALTER TABLE `suport_outro` DISABLE KEYS */;
INSERT INTO `suport_outro` VALUES (1,'CD');
/*!40000 ALTER TABLE `suport_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_som_filme`
--

LOCK TABLES `tipo_som_filme` WRITE;
/*!40000 ALTER TABLE `tipo_som_filme` DISABLE KEYS */;
INSERT INTO `tipo_som_filme` VALUES (1,'Dolby Digital'),(2,'Mono');
/*!40000 ALTER TABLE `tipo_som_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `topico`
--

LOCK TABLES `topico` WRITE;
/*!40000 ALTER TABLE `topico` DISABLE KEYS */;
INSERT INTO `topico` VALUES (38,1,29,1,0),(37,1,9,1,0);
/*!40000 ALTER TABLE `topico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trilha_album`
--

LOCK TABLES `trilha_album` WRITE;
/*!40000 ALTER TABLE `trilha_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `trilha_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trilha_genero_album`
--

LOCK TABLES `trilha_genero_album` WRITE;
/*!40000 ALTER TABLE `trilha_genero_album` DISABLE KEYS */;
INSERT INTO `trilha_genero_album` VALUES (1,'Rock'),(2,'Coro');
/*!40000 ALTER TABLE `trilha_genero_album` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-04-23 12:01:59
