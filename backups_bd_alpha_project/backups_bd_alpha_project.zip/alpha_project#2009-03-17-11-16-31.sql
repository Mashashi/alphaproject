-- MySQL dump 10.11
--
-- Host: localhost    Database: alpha_project
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `controlo_votacao`
--

LOCK TABLES `controlo_votacao` WRITE;
/*!40000 ALTER TABLE `controlo_votacao` DISABLE KEYS */;
/*!40000 ALTER TABLE `controlo_votacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_album`
--

LOCK TABLES `copi_album` WRITE;
/*!40000 ALTER TABLE `copi_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `copi_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_filme`
--

LOCK TABLES `copi_filme` WRITE;
/*!40000 ALTER TABLE `copi_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `copi_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `copi_outro`
--

LOCK TABLES `copi_outro` WRITE;
/*!40000 ALTER TABLE `copi_outro` DISABLE KEYS */;
/*!40000 ALTER TABLE `copi_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `direito_outro`
--

LOCK TABLES `direito_outro` WRITE;
/*!40000 ALTER TABLE `direito_outro` DISABLE KEYS */;
/*!40000 ALTER TABLE `direito_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `estatuto`
--

LOCK TABLES `estatuto` WRITE;
/*!40000 ALTER TABLE `estatuto` DISABLE KEYS */;
INSERT INTO `estatuto` VALUES (1,'Administrador',1,1,1,1,1,1,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `estatuto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `filme`
--

LOCK TABLES `filme` WRITE;
/*!40000 ALTER TABLE `filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `frase`
--

LOCK TABLES `frase` WRITE;
/*!40000 ALTER TABLE `frase` DISABLE KEYS */;
/*!40000 ALTER TABLE `frase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `genero_filme`
--

LOCK TABLES `genero_filme` WRITE;
/*!40000 ALTER TABLE `genero_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `genero_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `geral`
--

LOCK TABLES `geral` WRITE;
/*!40000 ALTER TABLE `geral` DISABLE KEYS */;
/*!40000 ALTER TABLE `geral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `mensagem`
--

LOCK TABLES `mensagem` WRITE;
/*!40000 ALTER TABLE `mensagem` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensagem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_album`
--

LOCK TABLES `num_suport_album` WRITE;
/*!40000 ALTER TABLE `num_suport_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `num_suport_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_filme`
--

LOCK TABLES `num_suport_filme` WRITE;
/*!40000 ALTER TABLE `num_suport_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `num_suport_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `num_suport_outro`
--

LOCK TABLES `num_suport_outro` WRITE;
/*!40000 ALTER TABLE `num_suport_outro` DISABLE KEYS */;
/*!40000 ALTER TABLE `num_suport_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `outro`
--

LOCK TABLES `outro` WRITE;
/*!40000 ALTER TABLE `outro` DISABLE KEYS */;
/*!40000 ALTER TABLE `outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `realizador_filme`
--

LOCK TABLES `realizador_filme` WRITE;
/*!40000 ALTER TABLE `realizador_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `realizador_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `registo`
--

LOCK TABLES `registo` WRITE;
/*!40000 ALTER TABLE `registo` DISABLE KEYS */;
INSERT INTO `registo` VALUES (1,1,'Admin','login','2008-09-20','1991-09-20',NULL,NULL,'a646745','2008-11-11 17:35:46',NULL,NULL,0,'Default','Default','0000-00-00',NULL);
/*!40000 ALTER TABLE `registo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `requesicao`
--

LOCK TABLES `requesicao` WRITE;
/*!40000 ALTER TABLE `requesicao` DISABLE KEYS */;
/*!40000 ALTER TABLE `requesicao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `requesicao_log`
--

LOCK TABLES `requesicao_log` WRITE;
/*!40000 ALTER TABLE `requesicao_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `requesicao_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_album`
--

LOCK TABLES `suport_album` WRITE;
/*!40000 ALTER TABLE `suport_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `suport_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_filme`
--

LOCK TABLES `suport_filme` WRITE;
/*!40000 ALTER TABLE `suport_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `suport_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suport_outro`
--

LOCK TABLES `suport_outro` WRITE;
/*!40000 ALTER TABLE `suport_outro` DISABLE KEYS */;
/*!40000 ALTER TABLE `suport_outro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_som_filme`
--

LOCK TABLES `tipo_som_filme` WRITE;
/*!40000 ALTER TABLE `tipo_som_filme` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_som_filme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `topico`
--

LOCK TABLES `topico` WRITE;
/*!40000 ALTER TABLE `topico` DISABLE KEYS */;
/*!40000 ALTER TABLE `topico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trilha_album`
--

LOCK TABLES `trilha_album` WRITE;
/*!40000 ALTER TABLE `trilha_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `trilha_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trilha_genero_album`
--

LOCK TABLES `trilha_genero_album` WRITE;
/*!40000 ALTER TABLE `trilha_genero_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `trilha_genero_album` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-03-17 11:16:46
